package com.personal.itemlog

import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.JalaliDate
import com.personal.itemlog.domain.TextNorm
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class JalaliTest {
    @Test
    fun knownGregorianToJalali() {
        assertEquals(JalaliDate(1405, 1, 1), Jalali.toJalali(LocalDate.of(2026, 3, 21)))
        assertEquals(JalaliDate(1404, 12, 29), Jalali.toJalali(LocalDate.of(2026, 3, 20)))
        assertEquals(JalaliDate(1405, 6, 30), Jalali.toJalali(LocalDate.of(2026, 9, 21)))
        assertEquals(JalaliDate(1403, 1, 1), Jalali.toJalali(LocalDate.of(2024, 3, 20)))
        assertEquals(JalaliDate(1403, 12, 30), Jalali.toJalali(LocalDate.of(2025, 3, 20)))
    }

    @Test
    fun knownJalaliToGregorian() {
        assertEquals(LocalDate.of(2026, 3, 21), Jalali.toGregorian(1405, 1, 1))
        assertEquals(LocalDate.of(2026, 9, 21), Jalali.toGregorian(1405, 6, 30))
        assertEquals(LocalDate.of(2025, 3, 20), Jalali.toGregorian(1403, 12, 30))
    }

    @Test
    fun roundTripOverManyYears() {
        var date = LocalDate.of(1990, 1, 1)
        val end = LocalDate.of(2060, 1, 1)
        while (date.isBefore(end)) {
            val j = Jalali.toJalali(date)
            assertEquals(date, Jalali.toGregorian(j.year, j.month, j.day))
            date = date.plusDays(1)
        }
    }

    @Test
    fun leapYearsAndMonthLengths() {
        assertTrue(Jalali.isLeap(1403))
        assertFalse(Jalali.isLeap(1404))
        assertFalse(Jalali.isLeap(1405))
        assertEquals(31, Jalali.monthLength(1405, 6))
        assertEquals(30, Jalali.monthLength(1405, 7))
        assertEquals(29, Jalali.monthLength(1405, 12))
        assertEquals(30, Jalali.monthLength(1403, 12))
    }

    @Test
    fun persianFormatting() {
        assertEquals("۳۰ شهریور ۱۴۰۵", Jalali.formatDate(LocalDate.of(2026, 9, 21)))
        assertEquals("۱۴۰۵/۰۶/۳۰", Jalali.formatNumeric(LocalDate.of(2026, 9, 21)))
        assertEquals("۰۹:۰۵", Jalali.formatTime(java.time.LocalTime.of(9, 5)))
    }

    @Test
    fun digitConversion() {
        assertEquals("0912", TextNorm.toLatinDigits("۰۹۱۲"))
        assertEquals("1234", TextNorm.toLatinDigits("١٢٣٤"))
        assertEquals("۱۲۳ abc", TextNorm.toPersianDigits("123 abc"))
    }
}
