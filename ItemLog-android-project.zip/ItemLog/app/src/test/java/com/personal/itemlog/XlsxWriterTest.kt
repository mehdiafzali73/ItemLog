package com.personal.itemlog

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.export.ExcelRows
import com.personal.itemlog.export.XlsxWriter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.ZoneOffset
import java.util.zip.ZipInputStream

class XlsxWriterTest {
    private fun unzip(bytes: ByteArray): Map<String, String> {
        val result = linkedMapOf<String, String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                result[e.name] = zip.readBytes().toString(Charsets.UTF_8)
                e = zip.nextEntry
            }
        }
        return result
    }

    @Test
    fun writesValidPackageWithRtlSheet() {
        val out = ByteArrayOutputStream()
        XlsxWriter.write(out, "گزارش", listOf("نام", "تعداد"), listOf(listOf("الف & ب <c>", 2.0), listOf("بدون تعداد", null)))
        val parts = unzip(out.toByteArray())
        assertTrue(parts.keys.containsAll(listOf(
            "[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels",
            "xl/styles.xml", "xl/worksheets/sheet1.xml"
        )))
        val sheet = parts.getValue("xl/worksheets/sheet1.xml")
        assertTrue(sheet.contains("rightToLeft=\"1\""))
        assertTrue(sheet.contains("الف &amp; ب &lt;c&gt;"))
        assertTrue(sheet.contains("<v>2.0</v>"))
        assertTrue(sheet.contains("r=\"A3\""))
        assertTrue(!sheet.contains("r=\"B3\""))
    }

    @Test
    fun columnNames() {
        assertEquals("A", XlsxWriter.columnName(0))
        assertEquals("Z", XlsxWriter.columnName(25))
        assertEquals("AA", XlsxWriter.columnName(26))
        assertEquals("AB", XlsxWriter.columnName(27))
    }

    @Test
    fun quantityBecomesNumberWhenPossible() {
        assertEquals(2.0, ExcelRows.quantityCell("۲"))
        assertEquals(2.5, ExcelRows.quantityCell("2.5"))
        assertEquals("۲ کارتن", ExcelRows.quantityCell("۲ کارتن"))
        assertEquals(null, ExcelRows.quantityCell("  "))
    }

    @Test
    fun rowsFollowHeaderColumns() {
        val r = ItemRecord(contactName = "علی", productName = "الف", quantity = "3", unit = "عدد", createdAt = 0)
        val rows = ExcelRows.rows(listOf(r), ZoneOffset.UTC)
        assertEquals(ExcelRows.HEADERS.size, rows.first().size)
        assertEquals("علی", rows.first()[2])
        assertEquals(3.0, rows.first()[6])
        assertEquals("فعال", rows.first()[10])
        assertEquals(null, rows.first()[11])
    }
}
