package com.personal.itemlog

import com.personal.itemlog.data.Attachment
import com.personal.itemlog.data.BackupCodec
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_DONE
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BackupCodecTest {
    private val records = listOf(
        ItemRecord(
            id = 1, contactKey = "k", contactName = "مهدی احمدی", contactPhone = "0912", productCode = "450",
            productName = "الکترود \"گرافیتی\"", quantity = "2", unit = "عدد", planningSite = "فولادسازی",
            notes = "خط اول\nخط دوم", status = STATUS_DONE, createdAt = 10, updatedAt = 20, completedAt = 30
        ),
        ItemRecord(id = 2, productName = "کابل", createdAt = 11, updatedAt = 11, deletedAt = 50)
    )
    private val attachments = listOf(
        Attachment(id = 5, recordId = 1, displayName = "عکس.jpg", mimeType = "image/jpeg", storedName = "a.jpg", sizeBytes = 99, createdAt = 12)
    )

    @Test
    fun roundTripKeepsEverything() {
        val json = BackupCodec.encode(records, attachments, mapOf("theme" to "dark"), 1234)
        val data = BackupCodec.decode(json)
        assertEquals(records, data.records)
        assertEquals(attachments, data.attachments)
        assertEquals("dark", data.settings["theme"])
        assertNull(data.records[1].completedAt)
        assertEquals(50L, data.records[1].deletedAt)
    }

    @Test
    fun invalidJsonIsRejected() {
        try {
            BackupCodec.decode("این JSON نیست")
            fail("باید خطا می‌داد")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.isNotEmpty())
        }
    }

    @Test
    fun futureVersionIsRejected() {
        try {
            BackupCodec.decode("""{"formatVersion": 99, "records": []}""")
            fail("باید خطا می‌داد")
        } catch (e: IllegalArgumentException) {
            assertTrue(true)
        }
    }

    @Test
    fun orphanAttachmentsAndPathTricksAreDropped() {
        val evil = attachments + Attachment(id = 6, recordId = 999, storedName = "x.bin") +
            Attachment(id = 7, recordId = 1, storedName = "../../etc/passwd")
        val data = BackupCodec.decode(BackupCodec.encode(records, evil, emptyMap(), 1))
        assertEquals(listOf(5L, 7L), data.attachments.map { it.id })
        assertEquals("passwd", data.attachments.last().storedName)
    }
}
