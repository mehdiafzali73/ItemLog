package com.personal.itemlog

import com.personal.itemlog.domain.PickedContact
import com.personal.itemlog.domain.SpeechText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechAndContactTest {
    @Test
    fun speechTextIsAppendedToExistingField() {
        assertEquals("الکترود", SpeechText.merge("", "  الکترود "))
        assertEquals("الکترود گرافیتی ۴۵۰", SpeechText.merge("الکترود گرافیتی ", "۴۵۰"))
        assertEquals("متن", SpeechText.merge("متن", "   "))
    }

    private val contact = PickedContact("k", "مهدی احمدی", "+98 912 123 4567")

    @Test
    fun contactSearchByFirstNameLastNameAndPhone() {
        assertTrue(contact.matches("مهدی"))
        assertTrue(contact.matches("احمدی"))
        assertTrue(contact.matches("احمدی مهدی"))
        assertTrue(contact.matches("0912"))
        assertTrue(contact.matches("۰۹۱۲۱۲۳"))
        assertTrue(contact.matches("4567"))
        assertTrue(contact.matches(""))
        assertFalse(contact.matches("رضایی"))
        assertFalse(contact.matches("0935"))
    }
}
