package com.personal.itemlog

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_ACTIVE
import com.personal.itemlog.data.STATUS_DONE
import com.personal.itemlog.domain.asDuplicate
import com.personal.itemlog.domain.hasContent
import com.personal.itemlog.domain.isDeleted
import com.personal.itemlog.domain.isDone
import com.personal.itemlog.domain.markDone
import com.personal.itemlog.domain.reopen
import com.personal.itemlog.domain.softDelete
import com.personal.itemlog.domain.undelete
import com.personal.itemlog.domain.withCompletionNormalized
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RecordOpsTest {
    private val base = ItemRecord(
        id = 7, contactName = "مهدی احمدی", productName = "کابل", quantity = "10", unit = "متر",
        createdAt = 1000, updatedAt = 1000
    )

    @Test
    fun newRecordIsActive() {
        assertEquals(STATUS_ACTIVE, base.status)
        assertFalse(base.isDone)
        assertFalse(base.isDeleted)
    }

    @Test
    fun editKeepsCreatedAtAndBumpsUpdatedAt() {
        val edited = base.copy(productName = "کابل ۴ رشته", updatedAt = 2000)
        assertEquals(1000L, edited.createdAt)
        assertEquals(2000L, edited.updatedAt)
        assertEquals("کابل", base.productName)
    }

    @Test
    fun completeStoresTimeAndCanBeReopened() {
        val done = base.markDone(5000)
        assertTrue(done.isDone)
        assertEquals(5000L, done.completedAt)
        assertEquals(STATUS_DONE, done.status)
        val again = done.reopen(6000)
        assertFalse(again.isDone)
        assertNull(again.completedAt)
        assertEquals(1000L, again.createdAt)
    }

    @Test
    fun softDeleteAndUndo() {
        val deleted = base.softDelete(3000)
        assertTrue(deleted.isDeleted)
        assertEquals(3000L, deleted.deletedAt)
        val restored = deleted.undelete(4000)
        assertFalse(restored.isDeleted)
        assertEquals(base.productName, restored.productName)
    }

    @Test
    fun duplicateIsIndependentAndActive() {
        val copy = base.markDone(2000).asDuplicate(9000)
        assertEquals(0L, copy.id)
        assertEquals(STATUS_ACTIVE, copy.status)
        assertEquals(9000L, copy.createdAt)
        assertNull(copy.completedAt)
        assertEquals("کابل", copy.productName)
    }

    @Test
    fun completionNormalizedFromFormStatus() {
        assertEquals(500L, base.copy(status = STATUS_DONE).withCompletionNormalized(500).completedAt)
        assertNull(base.copy(status = STATUS_ACTIVE, completedAt = 10).withCompletionNormalized(500).completedAt)
        assertEquals(10L, base.copy(status = STATUS_DONE, completedAt = 10).withCompletionNormalized(500).completedAt)
    }

    @Test
    fun anyFieldCountsAsContent() {
        assertFalse(ItemRecord().hasContent())
        assertTrue(ItemRecord(notes = "فقط توضیحات").hasContent())
        assertTrue(ItemRecord(productName = "فقط نام").hasContent())
    }
}
