package com.personal.itemlog

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_DONE
import com.personal.itemlog.domain.DatePreset
import com.personal.itemlog.domain.DateRanges
import com.personal.itemlog.domain.GroupOrder
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.RecordQuery
import com.personal.itemlog.domain.ReportFilter
import com.personal.itemlog.domain.StatusFilter
import com.personal.itemlog.domain.applyQuery
import com.personal.itemlog.domain.contactIdentity
import com.personal.itemlog.domain.groupRecords
import com.personal.itemlog.domain.softDelete
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset

class QueryTest {
    private val utc = ZoneOffset.UTC
    private val today = LocalDate.of(2026, 9, 21) // دوشنبه

    private fun at(date: LocalDate, hour: Int = 10): Long = Jalali.startOfDay(date, utc) + hour * 3_600_000L

    private val electrode = ItemRecord(
        id = 1, contactKey = "k1", contactName = "مهدی احمدی", contactPhone = "09121234567",
        productCode = "450", productName = "الکترود گرافیتی", quantity = "2", unit = "عدد",
        planningSite = "فولادسازی", notes = "فوری", createdAt = at(today, 9)
    )
    private val cable = ItemRecord(
        id = 2, contactKey = "k1", contactName = "مهدی احمدی", contactPhone = "09121234567",
        productName = "کابل", quantity = "10", unit = "متر", createdAt = at(today, 11)
    )
    private val bolt = ItemRecord(
        id = 3, contactKey = "k2", contactName = "علی رضایی", contactPhone = "09350000000",
        productName = "پیچ و مهره", quantity = "50", unit = "عدد", planningSite = "سایت سفارشات ۲",
        status = STATUS_DONE, completedAt = at(today, 12), createdAt = at(today.minusDays(1), 15)
    )
    private val old = ItemRecord(id = 4, productName = "قدیمی", createdAt = at(today.minusDays(40)))
    private val all = listOf(electrode, cable, bolt, old)

    @Test
    fun searchByNameCodeAndPhoneWithPersianDigits() {
        assertEquals(listOf(1L), all.applyQuery(RecordQuery(text = "الکترود")).map { it.id })
        assertEquals(listOf(1L), all.applyQuery(RecordQuery(text = "۴۵۰")).map { it.id })
        assertEquals(setOf(1L, 2L), all.applyQuery(RecordQuery(text = "0912")).map { it.id }.toSet())
        assertEquals(setOf(1L, 2L), all.applyQuery(RecordQuery(text = "مهدی")).map { it.id }.toSet())
        assertEquals(listOf(3L), all.applyQuery(RecordQuery(text = "سفارشات 2")).map { it.id })
        assertTrue(all.applyQuery(RecordQuery(text = "وجود ندارد")).isEmpty())
    }

    @Test
    fun searchNormalizesArabicLetters() {
        val r = ItemRecord(id = 9, productName = "کیسه", createdAt = 1)
        assertEquals(1, listOf(r).applyQuery(RecordQuery(text = "كيسه")).size)
    }

    @Test
    fun statusFilter() {
        assertEquals(setOf(1L, 2L, 4L), all.applyQuery(RecordQuery(status = StatusFilter.ACTIVE)).map { it.id }.toSet())
        assertEquals(listOf(3L), all.applyQuery(RecordQuery(status = StatusFilter.DONE)).map { it.id })
        assertEquals(4, all.applyQuery(RecordQuery(status = StatusFilter.ALL)).size)
    }

    @Test
    fun deletedRecordsAreNeverListed() {
        val list = listOf(electrode.softDelete(1), cable)
        assertEquals(listOf(2L), list.applyQuery(RecordQuery()).map { it.id })
    }

    @Test
    fun combinedFilters() {
        val (from, to) = DateRanges.toMillis(today, today, utc)
        val q = RecordQuery(fromMillis = from, toMillisExclusive = to, contactId = "k1", site = "فولاد", status = StatusFilter.ACTIVE)
        assertEquals(listOf(1L), all.applyQuery(q).map { it.id })
    }

    @Test
    fun contactIdentity() {
        assertEquals("k1", electrode.contactIdentity())
        assertNull(old.contactIdentity())
        assertEquals("علی|0935", ItemRecord(contactName = "علی", contactPhone = "0935").contactIdentity())
    }

    @Test
    fun groupsByContactAndDay() {
        val groups = groupRecords(all, GroupOrder.RECENT_FIRST, utc)
        assertEquals(3, groups.size) // مهدی امروز، علی دیروز، بدون مخاطب
        val first = groups.first()
        assertEquals("مهدی احمدی", first.contactName)
        assertEquals(listOf(2L, 1L), first.records.map { it.id })
        assertEquals(today, first.date)
    }

    @Test
    fun reportGroupingIsChronologicalPerContact() {
        val groups = groupRecords(all.filter { it.id != 4L }, GroupOrder.BY_CONTACT, utc)
        val mehdi = groups.first { it.contactName == "مهدی احمدی" }
        assertEquals(listOf(1L, 2L), mehdi.records.map { it.id })
    }

    @Test
    fun datePresets() {
        assertEquals(LocalDate.of(2026, 9, 19), DateRanges.weekStart(today)) // شنبه
        val (weekFrom, weekTo) = DateRanges.datesFor(DatePreset.WEEK, null, null, today)
        assertEquals(LocalDate.of(2026, 9, 19), weekFrom)
        assertEquals(today, weekTo)
        val (monthFrom, _) = DateRanges.datesFor(DatePreset.MONTH, null, null, today)
        assertEquals(Jalali.toGregorian(1405, 6, 1), monthFrom)
        val (yFrom, yTo) = DateRanges.datesFor(DatePreset.YESTERDAY, null, null, today)
        assertEquals(today.minusDays(1), yFrom)
        assertEquals(today.minusDays(1), yTo)
        val (aFrom, aTo) = DateRanges.datesFor(DatePreset.ALL, null, null, today)
        assertNull(aFrom)
        assertNull(aTo)
    }

    @Test
    fun reportFilterProducesQueryAndDescription() {
        val f = ReportFilter(preset = DatePreset.TODAY, contactId = "k1", contactLabel = "مهدی احمدی", status = StatusFilter.ACTIVE)
        val ids = all.applyQuery(f.toQuery(today, utc)).map { it.id }.toSet()
        assertEquals(setOf(1L, 2L), ids)
        val text = f.describe(today)
        assertTrue(text.contains("مخاطب: مهدی احمدی"))
        assertTrue(text.contains("وضعیت: فعال"))
        val custom = ReportFilter(preset = DatePreset.CUSTOM, customFrom = today.minusDays(1), customTo = today)
        assertEquals(3, all.applyQuery(custom.toQuery(today, utc)).size)
    }
}

class HomeStatsTest {
    private val utc = java.time.ZoneOffset.UTC
    private val today = java.time.LocalDate.of(2026, 9, 21)
    private val start = com.personal.itemlog.domain.Jalali.startOfDay(today, utc)

    @org.junit.Test
    fun countsActiveTodayAndFollowUp() {
        val list = listOf(
            ItemRecord(id = 1, createdAt = start + 1000),
            ItemRecord(id = 2, createdAt = start - 5000),
            ItemRecord(id = 3, createdAt = start - 9000, status = STATUS_DONE),
            ItemRecord(id = 4, createdAt = start + 2000).softDelete(1)
        )
        val stats = com.personal.itemlog.domain.computeStats(list, today, utc)
        org.junit.Assert.assertEquals(2, stats.activeCount)
        org.junit.Assert.assertEquals(1, stats.todayCount)
        org.junit.Assert.assertEquals(listOf(2L), stats.followUp.map { it.id })
    }

    @org.junit.Test
    fun weekdayNames() {
        org.junit.Assert.assertEquals("دوشنبه", com.personal.itemlog.domain.Jalali.weekdayName(today))
        org.junit.Assert.assertEquals("شنبه", com.personal.itemlog.domain.Jalali.weekdayName(today.minusDays(2)))
    }
}
