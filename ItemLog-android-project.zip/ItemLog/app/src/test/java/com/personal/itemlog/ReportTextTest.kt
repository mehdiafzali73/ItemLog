package com.personal.itemlog

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_DONE
import com.personal.itemlog.domain.GroupOrder
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.ReportText
import com.personal.itemlog.domain.StatusDisplay
import com.personal.itemlog.domain.groupRecords
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset

class ReportTextTest {
    private val utc = ZoneOffset.UTC
    private val day = LocalDate.of(2026, 9, 19)
    private val ms = Jalali.startOfDay(day, utc) + 36_000_000L

    private fun textFor(vararg records: ItemRecord, status: StatusDisplay = StatusDisplay.ALWAYS) =
        ReportText.build(groupRecords(records.toList(), GroupOrder.BY_CONTACT, utc), null, status)

    @Test
    fun emptyFieldsAreOmitted() {
        val text = textFor(ItemRecord(contactName = "مهدی احمدی", productName = "کابل", createdAt = ms))
        assertTrue(text.contains("مهدی احمدی"))
        assertTrue(text.contains("کابل"))
        assertFalse(text.contains("کد"))
        assertFalse(text.contains("سایت"))
        assertFalse(text.contains("توضیحات"))
        assertFalse(text.contains("متر"))
    }

    @Test
    fun fullRecordShowsEveryField() {
        val r = ItemRecord(
            contactName = "مهدی احمدی", contactPhone = "09121234567", productCode = "450",
            productName = "الکترود گرافیتی", quantity = "2", unit = "عدد", planningSite = "فولادسازی",
            notes = "فوری", createdAt = ms
        )
        val text = textFor(r)
        assertTrue(text.contains("مهدی احمدی — 09121234567"))
        assertTrue(text.contains("۲۸ شهریور ۱۴۰۵"))
        assertTrue(text.contains("۱. الکترود گرافیتی (کد 450) — 2 عدد"))
        assertTrue(text.contains("سایت برنامه‌ریزی: فولادسازی"))
        assertTrue(text.contains("توضیحات: فوری"))
        assertTrue(text.contains("وضعیت: فعال"))
    }

    @Test
    fun quantityWithoutUnitAndUnitWithoutQuantity() {
        assertEquals("الف — 5", ReportText.mainLine(ItemRecord(productName = "الف", quantity = "5")))
        assertEquals("الف — عدد", ReportText.mainLine(ItemRecord(productName = "الف", unit = "عدد")))
        assertEquals("—", ReportText.mainLine(ItemRecord(notes = "x")))
    }

    @Test
    fun smsStatusOnlyForDoneRecords() {
        val a = ItemRecord(id = 1, contactName = "علی", productName = "الف", createdAt = ms)
        val b = ItemRecord(id = 2, contactName = "علی", productName = "ب", status = STATUS_DONE, completedAt = ms, createdAt = ms + 1)
        val text = textFor(a, b, status = StatusDisplay.DONE_ONLY)
        assertEquals(1, Regex("وضعیت: اتمام").findAll(text).count())
        assertFalse(text.contains("وضعیت: فعال"))
    }

    @Test
    fun recordWithoutContactGetsNeutralHeader() {
        val text = textFor(ItemRecord(productName = "الف", createdAt = ms))
        assertTrue(text.startsWith("بدون مخاطب"))
    }
}
