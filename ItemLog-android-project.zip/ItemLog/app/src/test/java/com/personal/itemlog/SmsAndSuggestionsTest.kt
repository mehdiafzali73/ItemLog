package com.personal.itemlog

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_DONE
import com.personal.itemlog.data.TemplateCodec
import com.personal.itemlog.domain.DefaultTemplates
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.SmsBuilder
import com.personal.itemlog.domain.SmsItemStyle
import com.personal.itemlog.domain.SmsTemplate
import com.personal.itemlog.domain.Suggestions
import com.personal.itemlog.domain.softDelete
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset

class SmsAndSuggestionsTest {
    private val utc = ZoneOffset.UTC
    private val day = LocalDate.of(2026, 9, 19)
    private val ms = Jalali.startOfDay(day, utc) + 36_000_000L
    private val template = SmsTemplate("t", "نمونه", "سلام {نام} عزیز\nاقلام {تعداد} گانه برای {تاریخ}:", "با تشکر")

    private val full = ItemRecord(
        id = 1, productCode = "450", productName = "الکترود گرافیتی", quantity = "2", unit = "عدد",
        planningSite = "فولادسازی", notes = "فوری", createdAt = ms
    )
    private val simple = ItemRecord(id = 2, productName = "کابل", quantity = "10", unit = "متر", createdAt = ms + 1)

    @Test
    fun detailedMessageHasHeaderItemsAndFooter() {
        val text = SmsBuilder.render(template, "مهدی احمدی", listOf(full, simple), SmsItemStyle.DETAILED, utc)
        val expected = "سلام مهدی احمدی عزیز\nاقلام ۲ گانه برای ۲۸ شهریور ۱۴۰۵:\n\n" +
            "۱) الکترود گرافیتی\n   کد کالا: 450\n   تعداد: 2 عدد\n   سایت برنامه‌ریزی: فولادسازی\n   توضیحات: فوری\n\n" +
            "۲) کابل\n   تعداد: 10 متر\n\nبا تشکر"
        assertEquals(expected, text)
    }

    @Test
    fun compactMessageIsOneLinePerItem() {
        val text = SmsBuilder.render(template, "علی", listOf(full, simple), SmsItemStyle.COMPACT, utc)
        assertTrue(text.contains("۱) الکترود گرافیتی (کد 450) — 2 عدد | سایت: فولادسازی | فوری\n۲) کابل — 10 متر"))
    }

    @Test
    fun emptyFieldsNeverAppear() {
        val text = SmsBuilder.render(template, "علی", listOf(simple), SmsItemStyle.DETAILED, utc)
        assertFalse(text.contains("کد کالا"))
        assertFalse(text.contains("سایت"))
        assertFalse(text.contains("توضیحات"))
        assertFalse(text.contains("وضعیت"))
    }

    @Test
    fun blankNameDropsGreetingName() {
        val text = SmsBuilder.render(template, "  ", listOf(simple), SmsItemStyle.COMPACT, utc)
        assertTrue(text.startsWith("سلام\n"))
    }

    @Test
    fun multiDayRecordsGetDateHeadings() {
        val other = ItemRecord(id = 3, productName = "پیچ", createdAt = ms + 86_400_000L)
        val text = SmsBuilder.render(template, "علی", listOf(simple, other), SmsItemStyle.COMPACT, utc)
        assertTrue(text.contains("— ۲۸ شهریور ۱۴۰۵ —"))
        assertTrue(text.contains("— ۲۹ شهریور ۱۴۰۵ —"))
        assertTrue(text.contains("از ۲۸ شهریور ۱۴۰۵ تا ۲۹ شهریور ۱۴۰۵"))
    }

    @Test
    fun doneItemsAreMarkedAndDeletedIgnored() {
        val done = simple.copy(status = STATUS_DONE, completedAt = ms)
        val text = SmsBuilder.render(template, "علی", listOf(done, full.softDelete(5)), SmsItemStyle.DETAILED, utc)
        assertTrue(text.contains("وضعیت: اتمام"))
        assertFalse(text.contains("الکترود"))
    }

    @Test
    fun templateWithoutFooterEndsWithItems() {
        val t = SmsTemplate("x", "x", "لیست:")
        val text = SmsBuilder.render(t, "علی", listOf(simple), SmsItemStyle.COMPACT, utc)
        assertEquals("لیست:\n\n۱) کابل — 10 متر", text)
    }

    @Test
    fun templateCodecRoundTripAndInvalid() {
        val list = DefaultTemplates.create()
        assertEquals(list, TemplateCodec.decode(TemplateCodec.encode(list)))
        assertNull(TemplateCodec.decode("خراب"))
        assertNull(TemplateCodec.decode(null))
    }

    @Test
    fun suggestionsRankedByFrequencyThenRecency() {
        val list = listOf(
            ItemRecord(id = 1, planningSite = "فولادسازی", createdAt = 1),
            ItemRecord(id = 2, planningSite = "فولادسازی ", createdAt = 2),
            ItemRecord(id = 3, planningSite = "پروژه ۲", createdAt = 9),
            ItemRecord(id = 4, planningSite = "", createdAt = 10),
            ItemRecord(id = 5, planningSite = "قدیمی", createdAt = 3).softDelete(4)
        )
        assertEquals(listOf("فولادسازی", "پروژه ۲"), Suggestions.forField(list) { it.planningSite })
    }

    @Test
    fun suggestionFilteringByTypedText() {
        val all = listOf("فولادسازی", "سایت فولاد", "پروژه", "عدد")
        assertEquals(listOf("فولادسازی", "سایت فولاد"), Suggestions.filter(all, "فولاد"))
        assertEquals(emptyList<String>(), Suggestions.filter(all, "فولادسازی"))
        assertEquals(listOf("سایت فولاد"), Suggestions.filter(all, "سایت"))
        assertEquals(all, Suggestions.filter(all, ""))
        assertEquals(2, Suggestions.filter(all, "", limit = 2).size)
    }
}
