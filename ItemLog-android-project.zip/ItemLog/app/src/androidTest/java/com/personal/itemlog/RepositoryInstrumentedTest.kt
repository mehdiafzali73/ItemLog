package com.personal.itemlog

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.personal.itemlog.data.AppDatabase
import com.personal.itemlog.data.AppSettings
import com.personal.itemlog.data.Attachment
import com.personal.itemlog.data.FileStore
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.Repository
import com.personal.itemlog.data.STATUS_DONE
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** آزمون‌های دستگاهی: دیتابیس واقعی Room در حافظه + فایل‌های واقعی پیوست. */
@RunWith(AndroidJUnit4::class)
class RepositoryInstrumentedTest {
    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var files: FileStore
    private lateinit var repo: Repository
    private var now = 1_000_000L

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        files = FileStore(context)
        files.dir.listFiles()?.forEach { it.delete() }
        repo = Repository(context, db, files, AppSettings(context)) { now++ }
    }

    @After
    fun tearDown() {
        db.close()
        files.dir.listFiles()?.forEach { it.delete() }
    }

    private fun tempAttachment(name: String): Attachment {
        val stored = "test_$name.txt"
        files.file(stored).writeText("hello $name")
        return Attachment(displayName = "$name.txt", mimeType = "text/plain", storedName = stored, sizeBytes = 8)
    }

    @Test
    fun createEditCompleteDeleteRestore() = runBlocking {
        val id = repo.save(ItemRecord(contactName = "علی", productName = "کابل"), emptyList(), emptySet())
        var r = repo.load(id)!!.record
        assertTrue(r.createdAt > 0)

        repo.save(r.copy(productName = "کابل ۴ رشته"), emptyList(), emptySet())
        r = repo.load(id)!!.record
        assertEquals("کابل ۴ رشته", r.productName)
        assertTrue(r.updatedAt > r.createdAt)

        repo.setDone(id, true)
        assertEquals(STATUS_DONE, repo.load(id)!!.record.status)
        assertNotNull(repo.load(id)!!.record.completedAt)
        repo.setDone(id, false)
        assertNull(repo.load(id)!!.record.completedAt)

        repo.softDelete(id)
        assertNotNull(repo.load(id)!!.record.deletedAt)
        repo.restore(id)
        assertNull(repo.load(id)!!.record.deletedAt)
    }

    @Test
    fun attachmentsAreSavedAndRemovedWithFiles() = runBlocking {
        val a = tempAttachment("one")
        val id = repo.save(ItemRecord(productName = "الف"), listOf(a), emptySet())
        val saved = repo.load(id)!!.attachments
        assertEquals(1, saved.size)
        assertTrue(files.file(a.storedName).exists())

        repo.save(repo.load(id)!!.record, emptyList(), setOf(saved.first().id))
        assertTrue(repo.load(id)!!.attachments.isEmpty())
        assertFalse(files.file(a.storedName).exists())
    }

    @Test
    fun purgeRemovesRecordAndFiles() = runBlocking {
        val a = tempAttachment("two")
        val id = repo.save(ItemRecord(productName = "ب"), listOf(a), emptySet())
        repo.softDelete(id)
        repo.purge(id)
        assertNull(repo.load(id))
        assertFalse(files.file(a.storedName).exists())
    }

    @Test
    fun backupAndRestoreRoundTrip() = runBlocking {
        val a = tempAttachment("three")
        val id = repo.save(ItemRecord(contactName = "مهدی", productName = "الکترود"), listOf(a), emptySet())
        val out = ByteArrayOutputStream()
        repo.writeBackup(out)

        repo.softDelete(id)
        repo.purge(id)
        assertTrue(repo.records.first().isEmpty())

        val result = repo.restoreBackup(ByteArrayInputStream(out.toByteArray()))
        assertEquals(1, result.recordCount)
        val restored = repo.load(id)!!
        assertEquals("الکترود", restored.record.productName)
        assertEquals(1, restored.attachments.size)
        assertEquals("hello three", files.file(a.storedName).readText())
    }
}
