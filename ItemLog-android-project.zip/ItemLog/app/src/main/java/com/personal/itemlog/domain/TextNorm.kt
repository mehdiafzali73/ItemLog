package com.personal.itemlog.domain

object TextNorm {
    private const val PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
    private const val ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"

    fun toLatinDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val p = PERSIAN_DIGITS.indexOf(ch)
            val a = ARABIC_DIGITS.indexOf(ch)
            when {
                p >= 0 -> sb.append('0' + p)
                a >= 0 -> sb.append('0' + a)
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toPersianDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            if (ch in '0'..'9') sb.append(PERSIAN_DIGITS[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }

    /** یکسان‌سازی متن برای جستجو: ارقام لاتین، ی/ک فارسی، حذف نیم‌فاصله و اعراب، حروف کوچک. */
    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in toLatinDigits(s)) {
            when {
                ch == 'ي' || ch == 'ى' -> sb.append('ی')
                ch == 'ك' -> sb.append('ک')
                ch == '\u200c' || ch == '\u200d' || ch == 'ـ' -> Unit
                ch in '\u064B'..'\u065F' -> Unit
                else -> sb.append(ch)
            }
        }
        return sb.toString().lowercase().trim()
    }

    fun digitsOnly(s: String): String = toLatinDigits(s).filter { it in '0'..'9' }

    fun tokens(s: String): List<String> =
        normalize(s).split(' ', '\n', '\t').filter { it.isNotEmpty() }
}
