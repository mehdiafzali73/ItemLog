package com.personal.itemlog

import android.app.Application
import com.personal.itemlog.data.AppDatabase
import com.personal.itemlog.data.AppSettings
import com.personal.itemlog.data.FileStore
import com.personal.itemlog.data.Repository

class ItemLogApp : Application() {
    val database by lazy { AppDatabase.get(this) }
    val fileStore by lazy { FileStore(this) }
    val settings by lazy { AppSettings(this) }
    val repository by lazy { Repository(this, database, fileStore, settings) }
}
