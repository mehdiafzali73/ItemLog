package com.personal.itemlog.domain

import com.personal.itemlog.data.ItemRecord

/** پیشنهاد مقدارهای قبلاً ذخیره‌شده (سایت برنامه‌ریزی، واحد کالا) برای ثبت سریع‌تر. */
object Suggestions {
    /** پرتکرارترین مقدارها اول؛ در تساوی، جدیدترین. املای رایج‌تر هر مقدار نگه داشته می‌شود. */
    fun forField(
        records: List<ItemRecord>,
        limit: Int = 30,
        selector: (ItemRecord) -> String
    ): List<String> {
        class Entry(var count: Int, var latest: Long, val spellings: MutableMap<String, Int>)

        val map = LinkedHashMap<String, Entry>()
        for (r in records) {
            if (r.deletedAt != null) continue
            val raw = selector(r).trim()
            if (raw.isEmpty()) continue
            val key = TextNorm.normalize(raw)
            val entry = map.getOrPut(key) { Entry(0, 0L, mutableMapOf()) }
            entry.count++
            if (r.createdAt > entry.latest) entry.latest = r.createdAt
            entry.spellings[raw] = (entry.spellings[raw] ?: 0) + 1
        }
        return map.values
            .sortedWith(compareByDescending<Entry> { it.count }.thenByDescending { it.latest })
            .take(limit)
            .map { e -> e.spellings.entries.maxByOrNull { it.value }!!.key }
    }

    /** فیلتر پیشنهادها بر اساس متنی که کاربر تایپ کرده؛ مقدار دقیقاً برابر پیشنهاد نمی‌شود. */
    fun filter(all: List<String>, typed: String, limit: Int = 8): List<String> {
        val t = TextNorm.normalize(typed)
        if (t.isEmpty()) return all.take(limit)
        val matches = all.filter { s ->
            val n = TextNorm.normalize(s)
            n != t && n.contains(t)
        }
        val (starts, others) = matches.partition { TextNorm.normalize(it).startsWith(t) }
        return (starts + others).take(limit)
    }
}
