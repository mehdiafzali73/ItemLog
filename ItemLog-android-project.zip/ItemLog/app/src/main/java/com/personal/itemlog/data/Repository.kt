package com.personal.itemlog.data

import android.content.Context
import androidx.room.withTransaction
import com.personal.itemlog.domain.markDone
import com.personal.itemlog.domain.reopen
import com.personal.itemlog.domain.softDelete
import com.personal.itemlog.domain.undelete
import com.personal.itemlog.domain.withCompletionNormalized
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class LoadedRecord(val record: ItemRecord, val attachments: List<Attachment>)
data class RestoreResult(val recordCount: Int, val attachmentCount: Int)

class Repository(
    private val context: Context,
    private val db: AppDatabase,
    private val files: FileStore,
    private val settings: AppSettings,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val dao = db.dao()

    val records: Flow<List<ItemRecord>> = dao.observeAll()
    val attachments: Flow<List<Attachment>> = dao.observeAttachments()

    suspend fun load(id: Long): LoadedRecord? {
        val record = dao.getById(id) ?: return null
        return LoadedRecord(record, dao.attachmentsFor(id))
    }

    /** رکورد جدید (id=0) یا ویرایش‌شده را همراه با پیوست‌ها ذخیره می‌کند. */
    suspend fun save(record: ItemRecord, newAttachments: List<Attachment>, removedIds: Set<Long>): Long {
        val now = clock()
        val normalized = record.withCompletionNormalized(now)
        val filesToDelete = mutableListOf<String>()
        val id = db.withTransaction {
            val savedId = if (normalized.id == 0L) {
                dao.insert(normalized.copy(createdAt = now, updatedAt = now))
            } else {
                dao.update(normalized.copy(updatedAt = now))
                normalized.id
            }
            for (existing in dao.attachmentsFor(savedId)) {
                if (existing.id in removedIds) {
                    dao.deleteAttachment(existing.id)
                    filesToDelete += existing.storedName
                }
            }
            for (a in newAttachments) {
                if (a.id == 0L) dao.insertAttachment(a.copy(recordId = savedId))
            }
            savedId
        }
        filesToDelete.forEach { files.delete(it) }
        return id
    }

    suspend fun setDone(id: Long, done: Boolean) {
        val r = dao.getById(id) ?: return
        val now = clock()
        dao.update(if (done) r.markDone(now) else r.reopen(now))
    }

    suspend fun softDelete(id: Long) {
        val r = dao.getById(id) ?: return
        dao.update(r.softDelete(clock()))
    }

    suspend fun restore(id: Long) {
        val r = dao.getById(id) ?: return
        dao.update(r.undelete(clock()))
    }

    // ---------- عملیات گروهی (مثلاً همه‌ی موارد یک مخاطب) ----------

    suspend fun softDeleteAll(ids: List<Long>) {
        val now = clock()
        db.withTransaction {
            for (id in ids) dao.getById(id)?.let { dao.update(it.softDelete(now)) }
        }
    }

    suspend fun restoreAll(ids: List<Long>) {
        val now = clock()
        db.withTransaction {
            for (id in ids) dao.getById(id)?.let { dao.update(it.undelete(now)) }
        }
    }

    suspend fun setDoneAll(ids: List<Long>, done: Boolean) {
        val now = clock()
        db.withTransaction {
            for (id in ids) {
                val r = dao.getById(id) ?: continue
                dao.update(if (done) r.markDone(now) else r.reopen(now))
            }
        }
    }

    /** حذف همیشگی رکورد و فایل‌های پیوست آن. */
    suspend fun purge(id: Long) {
        val names = dao.attachmentsFor(id).map { it.storedName }
        dao.deleteById(id)
        names.forEach { files.delete(it) }
    }

    suspend fun emptyTrash() {
        dao.getAll().filter { it.deletedAt != null }.forEach { purge(it.id) }
    }

    /** فایل‌های پیوستی که هنوز ذخیره نشده‌اند (مثلاً با انصراف از فرم) پاک می‌شوند. */
    fun discardFiles(drafts: List<Attachment>) {
        drafts.filter { it.id == 0L }.forEach { files.delete(it.storedName) }
    }

    // ---------- پشتیبان‌گیری ----------

    suspend fun writeBackup(out: OutputStream) = withContext(Dispatchers.IO) {
        val recordList = dao.getAll()
        val attachmentList = dao.getAllAttachments()
        ZipOutputStream(BufferedOutputStream(out)).use { zip ->
            zip.putNextEntry(ZipEntry("data.json"))
            zip.write(
                BackupCodec.encode(recordList, attachmentList, settings.export(), clock())
                    .toByteArray(Charsets.UTF_8)
            )
            zip.closeEntry()
            for (a in attachmentList) {
                val f = files.file(a.storedName)
                if (!f.exists()) continue
                zip.putNextEntry(ZipEntry("attachments/${f.name}"))
                f.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    /** نسخه‌ی پشتیبان خودکار (قبل از Restore) در حافظه‌ی داخلی برنامه. */
    suspend fun createAutoBackup(): File = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, "auto_backups").also { it.mkdirs() }
        val target = File(dir, "auto_" + stamp(clock()) + ".zip")
        target.outputStream().use { writeBackup(it) }
        dir.listFiles()?.sortedByDescending { it.name }?.drop(5)?.forEach { it.delete() }
        target
    }

    /** پشتیبان موقت برای اشتراک‌گذاری. */
    suspend fun createShareableBackup(): File = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "exports").also { it.mkdirs() }
        val target = File(dir, backupFileName(clock()))
        target.outputStream().use { writeBackup(it) }
        target
    }

    /**
     * جایگزینی کامل داده‌ها با فایل پشتیبان. ابتدا از وضعیت فعلی یک پشتیبان خودکار گرفته می‌شود
     * و فایل ورودی قبل از هر تغییری کاملاً اعتبارسنجی می‌شود.
     */
    suspend fun restoreBackup(input: InputStream): RestoreResult = withContext(Dispatchers.IO) {
        val tmp = File(context.cacheDir, "restore_tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        try {
            var json: String? = null
            ZipInputStream(BufferedInputStream(input)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        if (entry.name == "data.json") {
                            json = zip.readBytes().toString(Charsets.UTF_8)
                        } else if (entry.name.startsWith("attachments/")) {
                            val name = File(entry.name).name
                            if (name.isNotBlank()) {
                                File(tmp, name).outputStream().use { sink -> zip.copyTo(sink) }
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            val text = json ?: throw IllegalArgumentException("فایل پشتیبان معتبر نیست")
            val data = BackupCodec.decode(text)

            createAutoBackup()

            db.withTransaction {
                dao.clearAttachments()
                dao.clearRecords()
                dao.insertAll(data.records)
                dao.insertAttachments(data.attachments)
            }
            files.replaceAllWith(tmp)
            settings.import(data.settings)
            RestoreResult(data.records.size, data.attachments.size)
        } finally {
            tmp.deleteRecursively()
        }
    }

    companion object {
        private fun stamp(ms: Long) = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(ms))

        fun backupFileName(ms: Long): String =
            "itemlog_backup_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date(ms)) + ".zip"
    }
}
