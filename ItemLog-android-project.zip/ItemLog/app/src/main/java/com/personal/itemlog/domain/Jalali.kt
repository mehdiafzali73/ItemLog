package com.personal.itemlog.domain

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

data class JalaliDate(val year: Int, val month: Int, val day: Int)

/** تبدیل تاریخ میلادی/شمسی و قالب‌بندی فارسی. */
object Jalali {
    val MONTH_NAMES = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    private val GREGORIAN_CUMULATIVE = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)

    fun toJalali(date: LocalDate): JalaliDate {
        val gy = date.year
        val gm = date.monthValue
        val gd = date.dayOfMonth
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
            ((gy2 + 399) / 400) + gd + GREGORIAN_CUMULATIVE[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return JalaliDate(jy, jm, jd)
    }

    fun toGregorian(jy0: Int, jm: Int, jd: Int): LocalDate {
        val jy = jy0 + 1595
        var days = -355668 + (365 * jy) + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + jd +
            (if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186)
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days -= 1
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val lengths = intArrayOf(31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 11 && gd > lengths[gm]) {
            gd -= lengths[gm]
            gm++
        }
        return LocalDate.of(gy, gm + 1, gd)
    }

    fun toGregorian(date: JalaliDate): LocalDate = toGregorian(date.year, date.month, date.day)

    fun isLeap(jy: Int): Boolean = toJalali(toGregorian(jy, 12, 30)) == JalaliDate(jy, 12, 30)

    fun monthLength(jy: Int, jm: Int): Int = when {
        jm <= 6 -> 31
        jm <= 11 -> 30
        else -> if (isLeap(jy)) 30 else 29
    }

    fun monthName(jm: Int): String = MONTH_NAMES.getOrElse(jm - 1) { "" }

    fun weekdayName(date: LocalDate): String = when (date.dayOfWeek) {
        DayOfWeek.SATURDAY -> "شنبه"
        DayOfWeek.SUNDAY -> "یکشنبه"
        DayOfWeek.MONDAY -> "دوشنبه"
        DayOfWeek.TUESDAY -> "سه‌شنبه"
        DayOfWeek.WEDNESDAY -> "چهارشنبه"
        DayOfWeek.THURSDAY -> "پنجشنبه"
        DayOfWeek.FRIDAY -> "جمعه"
    }

    fun dateOf(millis: Long, zone: ZoneId = ZoneId.systemDefault()): LocalDate =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()

    fun startOfDay(date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): Long =
        date.atStartOfDay(zone).toInstant().toEpochMilli()

    /** مثال: ۲۹ شهریور ۱۴۰۵ */
    fun formatDate(date: LocalDate): String {
        val j = toJalali(date)
        return TextNorm.toPersianDigits("${j.day} ${monthName(j.month)} ${j.year}")
    }

    fun formatDate(millis: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        formatDate(dateOf(millis, zone))

    /** مثال: ۱۴۰۵/۰۶/۲۹ */
    fun formatNumeric(date: LocalDate): String {
        val j = toJalali(date)
        return TextNorm.toPersianDigits("%04d/%02d/%02d".format(j.year, j.month, j.day))
    }

    fun formatNumeric(millis: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        formatNumeric(dateOf(millis, zone))

    fun formatTime(time: LocalTime): String =
        TextNorm.toPersianDigits("%02d:%02d".format(time.hour, time.minute))

    fun formatTime(millis: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        formatTime(Instant.ofEpochMilli(millis).atZone(zone).toLocalTime())

    fun formatDateTime(millis: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        "${formatDate(millis, zone)}، ${formatTime(millis, zone)}"
}
