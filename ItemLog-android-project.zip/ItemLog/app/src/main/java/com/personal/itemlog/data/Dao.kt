package com.personal.itemlog.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RecordDao {
    @Query("SELECT * FROM records ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ItemRecord>>

    @Query("SELECT * FROM records")
    suspend fun getAll(): List<ItemRecord>

    @Query("SELECT * FROM records WHERE id = :id")
    suspend fun getById(id: Long): ItemRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: ItemRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(records: List<ItemRecord>)

    @Update
    suspend fun update(record: ItemRecord)

    @Query("DELETE FROM records WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM records")
    suspend fun clearRecords()

    @Query("SELECT * FROM attachments ORDER BY id")
    fun observeAttachments(): Flow<List<Attachment>>

    @Query("SELECT * FROM attachments")
    suspend fun getAllAttachments(): List<Attachment>

    @Query("SELECT * FROM attachments WHERE recordId = :recordId ORDER BY id")
    suspend fun attachmentsFor(recordId: Long): List<Attachment>

    @Insert
    suspend fun insertAttachment(attachment: Attachment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachments(attachments: List<Attachment>)

    @Query("DELETE FROM attachments WHERE id = :id")
    suspend fun deleteAttachment(id: Long)

    @Query("DELETE FROM attachments")
    suspend fun clearAttachments()
}
