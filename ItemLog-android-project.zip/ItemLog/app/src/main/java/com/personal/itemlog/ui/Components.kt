@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import com.personal.itemlog.ItemLogApp
import com.personal.itemlog.data.Attachment
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.TextNorm
import com.personal.itemlog.domain.displayTitle
import com.personal.itemlog.domain.isDone
import com.personal.itemlog.export.ShareUtil
import java.time.LocalDate

fun sizeLabel(bytes: Long): String {
    val text = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
    }
    return TextNorm.toPersianDigits(text)
}

/** پیوست‌های تصویری داخل برنامه و بقیه‌ی فایل‌ها با برنامه‌ی مناسب گوشی باز می‌شوند. */
fun openAttachment(context: Context, attachment: Attachment, onImage: (Attachment) -> Unit) {
    if (attachment.isImage()) {
        onImage(attachment)
    } else {
        val store = (context.applicationContext as ItemLogApp).fileStore
        ShareUtil.openFile(context, store.uriFor(store.file(attachment.storedName)), attachment.mimeType)
    }
}

@Composable
fun AttachmentList(
    attachments: List<Attachment>,
    onOpen: (Attachment) -> Unit,
    modifier: Modifier = Modifier,
    onRemove: ((Attachment) -> Unit)? = null
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        attachments.forEach { a ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(a) }.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AttachmentThumb(a, 48.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                    Text(sizeLabel(a.sizeBytes), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { onOpen(a) }) { Text("مشاهده") }
                if (onRemove != null) {
                    IconButton(onClick = { onRemove(a) }) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف پیوست", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(done: Boolean) {
    val bg = if (done) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer
    val fg = if (done) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onPrimaryContainer
    Box(
        Modifier
            .background(bg, androidx.compose.foundation.shape.RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 2.dp)
    ) {
        Text(if (done) "اتمام" else "فعال", style = MaterialTheme.typography.labelSmall, color = fg)
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text("$label:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(6.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}

/** کارت رکورد؛ با لمس باز می‌شود و همه‌ی جزئیات، پیوست‌ها و عملیات را نشان می‌دهد. */
@Composable
fun RecordCard(
    record: ItemRecord,
    attachments: List<Attachment>,
    onEdit: () -> Unit,
    onToggleDone: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onOpenAttachment: (Attachment) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by rememberSaveable(record.id) { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    val done = record.isDone
    Card(
        onClick = { expanded = !expanded },
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (done) MaterialTheme.colorScheme.surfaceContainerLow else MaterialTheme.colorScheme.surfaceContainerHigh
        )
    ) {
        Column(Modifier.padding(start = 14.dp, top = 10.dp, end = 4.dp, bottom = 10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(
                        record.displayTitle(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = if (expanded) 4 else 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    val sub = listOf(
                        listOf(record.quantity.trim(), record.unit.trim()).filter { it.isNotEmpty() }.joinToString(" "),
                        record.planningSite.trim()
                    ).filter { it.isNotEmpty() }.joinToString("  •  ")
                    if (sub.isNotEmpty()) {
                        Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusBadge(done)
                        Text(
                            Jalali.formatTime(record.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (attachments.isNotEmpty()) {
                            Text(
                                "📎 " + TextNorm.toPersianDigits(attachments.size.toString()),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "عملیات")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text("ویرایش") }, onClick = { menuOpen = false; onEdit() })
                        DropdownMenuItem(
                            text = { Text(if (done) "بازگرداندن به فعال" else "اتمام") },
                            onClick = { menuOpen = false; onToggleDone() }
                        )
                        DropdownMenuItem(text = { Text("تکرار این رکورد") }, onClick = { menuOpen = false; onDuplicate() })
                        DropdownMenuItem(text = { Text("حذف") }, onClick = { menuOpen = false; onDelete() })
                    }
                }
            }
            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Column(Modifier.padding(end = 10.dp)) {
                    DetailLine("کد کالا", record.productCode.trim())
                    DetailLine("نام کالا", record.productName.trim())
                    DetailLine("تعداد", record.quantity.trim())
                    DetailLine("واحد", record.unit.trim())
                    DetailLine("سایت برنامه‌ریزی", record.planningSite.trim())
                    DetailLine("توضیحات", record.notes.trim())
                    DetailLine("ثبت", Jalali.formatDateTime(record.createdAt))
                    record.completedAt?.let { DetailLine("اتمام", Jalali.formatDateTime(it)) }
                    if (record.updatedAt - record.createdAt > 60_000) {
                        DetailLine("آخرین ویرایش", Jalali.formatDateTime(record.updatedAt))
                    }
                    if (attachments.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("پیوست‌ها", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        AttachmentList(attachments, onOpenAttachment)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                        TextButton(onClick = onEdit) { Text("ویرایش") }
                        TextButton(onClick = onToggleDone) { Text(if (done) "فعال کردن" else "اتمام") }
                        TextButton(onClick = onDuplicate) { Text("تکرار") }
                        TextButton(onClick = onDelete) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
}

/** انتخاب تاریخ شمسی با سه فیلد سال، ماه و روز. */
@Composable
fun JalaliDatePickerDialog(initial: LocalDate, onDismiss: () -> Unit, onConfirm: (LocalDate) -> Unit) {
    val j = remember(initial) { Jalali.toJalali(initial) }
    var year by remember { mutableStateOf(j.year.toString()) }
    var month by remember { mutableStateOf(j.month.toString()) }
    var day by remember { mutableStateOf(j.day.toString()) }

    val y = TextNorm.toLatinDigits(year).toIntOrNull()
    val m = TextNorm.toLatinDigits(month).toIntOrNull()
    val d = TextNorm.toLatinDigits(day).toIntOrNull()
    val valid = y != null && m != null && d != null && y in 1300..1500 && m in 1..12 &&
        d in 1..Jalali.monthLength(y, m)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("انتخاب تاریخ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = year, onValueChange = { year = it.take(4) }, label = { Text("سال") },
                        singleLine = true, modifier = Modifier.weight(1.3f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = month, onValueChange = { month = it.take(2) }, label = { Text("ماه") },
                        singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = day, onValueChange = { day = it.take(2) }, label = { Text("روز") },
                        singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                if (m != null && m in 1..12) {
                    Text(Jalali.monthName(m), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
                if (!valid) {
                    Text("تاریخ معتبر نیست", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = { onConfirm(Jalali.toGregorian(y!!, m!!, d!!)) }
            ) { Text("تأیید") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
