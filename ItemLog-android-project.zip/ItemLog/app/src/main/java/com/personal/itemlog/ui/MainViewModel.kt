package com.personal.itemlog.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.personal.itemlog.ItemLogApp
import com.personal.itemlog.data.Attachment
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.LoadedRecord
import com.personal.itemlog.domain.GroupOrder
import com.personal.itemlog.domain.RecordGroup
import com.personal.itemlog.domain.RecordQuery
import com.personal.itemlog.domain.ReportFilter
import com.personal.itemlog.domain.StatusFilter
import com.personal.itemlog.domain.applyQuery
import com.personal.itemlog.domain.contactIdentity
import com.personal.itemlog.domain.groupRecords
import com.personal.itemlog.export.ReportExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.time.LocalDate

data class UiMessage(
    val text: String,
    val actionLabel: String? = null,
    val onAction: (() -> Unit)? = null
)

data class ContactOption(val id: String, val label: String)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as ItemLogApp
    private val repo = app.repository
    private val exporter = ReportExporter(application)
    val settings = app.settings

    private val messageChannel = Channel<UiMessage>(Channel.BUFFERED)
    val messages = messageChannel.receiveAsFlow()

    val busy = MutableStateFlow(false)

    // ---------- داده‌ها ----------
    val records: StateFlow<List<ItemRecord>> =
        repo.records.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val attachmentsByRecord: StateFlow<Map<Long, List<Attachment>>> =
        repo.attachments.map { list -> list.groupBy { it.recordId } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    // ---------- صفحه اصلی ----------
    val homeSearch = MutableStateFlow("")
    val homeStatus = MutableStateFlow(StatusFilter.ACTIVE)

    val homeGroups: StateFlow<List<RecordGroup>> =
        combine(records, homeSearch, homeStatus) { list, text, status ->
            groupRecords(list.applyQuery(RecordQuery(text = text, status = status)), GroupOrder.RECENT_FIRST)
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---------- گزارش‌ها ----------
    val reportFilter = MutableStateFlow(ReportFilter())

    val reportRecords: StateFlow<List<ItemRecord>> =
        combine(records, reportFilter) { list, filter ->
            list.applyQuery(filter.toQuery(LocalDate.now())).sortedBy { it.createdAt }
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val reportGroups: StateFlow<List<RecordGroup>> =
        reportRecords.map { groupRecords(it, GroupOrder.BY_CONTACT) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val contactOptions: StateFlow<List<ContactOption>> =
        records.map { list ->
            list.filter { it.deletedAt == null }
                .mapNotNull { r ->
                    r.contactIdentity()?.let { id ->
                        ContactOption(
                            id,
                            listOf(r.contactName.trim(), r.contactPhone.trim())
                                .filter { it.isNotEmpty() }.joinToString(" — ")
                        )
                    }
                }
                .distinctBy { it.id }
                .sortedBy { it.label }
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun updateReportFilter(transform: (ReportFilter) -> ReportFilter) {
        reportFilter.update(transform)
    }

    // ---------- سطل بازیافت ----------
    val trash: StateFlow<List<ItemRecord>> =
        records.map { list -> list.filter { it.deletedAt != null }.sortedByDescending { it.deletedAt } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---------- عملیات روی رکورد ----------
    suspend fun loadRecord(id: Long): LoadedRecord? = repo.load(id)

    fun save(
        record: ItemRecord,
        newAttachments: List<Attachment>,
        removedIds: Set<Long>,
        onSaved: (Long) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val id = repo.save(record, newAttachments, removedIds)
                onSaved(id)
            } catch (e: Exception) {
                say("ذخیره انجام نشد: ${e.message ?: "خطای نامشخص"}")
            }
        }
    }

    fun discardDrafts(drafts: List<Attachment>) {
        repo.discardFiles(drafts)
    }

    fun complete(id: Long) {
        viewModelScope.launch {
            repo.setDone(id, true)
            say("رکورد اتمام شد", "واگرد") { reopen(id, quiet = true) }
        }
    }

    fun reopen(id: Long, quiet: Boolean = false) {
        viewModelScope.launch {
            repo.setDone(id, false)
            if (!quiet) say("رکورد دوباره فعال شد")
        }
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            repo.softDelete(id)
            say("رکورد حذف شد", "واگرد") { restore(id, quiet = true) }
        }
    }

    fun restore(id: Long, quiet: Boolean = false) {
        viewModelScope.launch {
            repo.restore(id)
            if (!quiet) say("رکورد بازگردانی شد")
        }
    }

    fun purge(id: Long) {
        viewModelScope.launch {
            repo.purge(id)
            say("رکورد برای همیشه حذف شد")
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repo.emptyTrash()
            say("سطل حذف‌شده‌ها خالی شد")
        }
    }

    // ---------- خروجی ----------
    fun exportPdf(onReady: (File) -> Unit) {
        val groups = reportGroups.value
        if (groups.isEmpty()) return
        val filter = reportFilter.value
        viewModelScope.launch {
            busy.value = true
            try {
                val file = exporter.createPdf("گزارش کالاها", filter.describe(LocalDate.now()), groups)
                onReady(file)
            } catch (e: Exception) {
                say("ساخت PDF انجام نشد: ${e.message ?: "خطای نامشخص"}")
            } finally {
                busy.value = false
            }
        }
    }

    fun exportExcel(onReady: (File) -> Unit) {
        val list = reportGroups.value.flatMap { it.records }
        if (list.isEmpty()) return
        viewModelScope.launch {
            busy.value = true
            try {
                onReady(exporter.createXlsx(list))
            } catch (e: Exception) {
                say("ساخت Excel انجام نشد: ${e.message ?: "خطای نامشخص"}")
            } finally {
                busy.value = false
            }
        }
    }

    // ---------- پشتیبان‌گیری ----------
    fun backupTo(uri: Uri) {
        viewModelScope.launch {
            busy.value = true
            try {
                val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                    ?: throw IOException("امکان نوشتن در مقصد وجود ندارد")
                out.use { repo.writeBackup(it) }
                say("پشتیبان با موفقیت ذخیره شد")
            } catch (e: Exception) {
                say("پشتیبان‌گیری انجام نشد: ${e.message ?: "خطای نامشخص"}")
            } finally {
                busy.value = false
            }
        }
    }

    fun createShareableBackup(onReady: (File) -> Unit) {
        viewModelScope.launch {
            busy.value = true
            try {
                onReady(repo.createShareableBackup())
            } catch (e: Exception) {
                say("پشتیبان‌گیری انجام نشد: ${e.message ?: "خطای نامشخص"}")
            } finally {
                busy.value = false
            }
        }
    }

    fun restoreFrom(uri: Uri) {
        viewModelScope.launch {
            busy.value = true
            try {
                val result = withContext(Dispatchers.IO) {
                    val input = getApplication<Application>().contentResolver.openInputStream(uri)
                        ?: throw IOException("امکان خواندن فایل وجود ندارد")
                    input.use { repo.restoreBackup(it) }
                }
                say("بازیابی انجام شد (${result.recordCount} رکورد)")
            } catch (e: Exception) {
                say("بازیابی انجام نشد: ${e.message ?: "خطای نامشخص"}")
            } finally {
                busy.value = false
            }
        }
    }

    private suspend fun say(text: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
        messageChannel.send(UiMessage(text, actionLabel, onAction))
    }
}
