package com.personal.itemlog.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.Contacts
import androidx.core.content.ContextCompat
import com.personal.itemlog.domain.PickedContact
import com.personal.itemlog.domain.TextNorm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

/** خواندن مخاطبین از Contact Provider استاندارد اندروید (شامل Google Contacts و مخاطبین گوشی). */
object ContactsSource {
    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    suspend fun loadAll(context: Context): List<PickedContact> = withContext(Dispatchers.IO) {
        val result = ArrayList<PickedContact>()
        val seen = HashSet<String>()
        try {
            val resolver = context.contentResolver

            resolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.LOOKUP_KEY, Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, null
            )?.use { c ->
                val keyIndex = c.getColumnIndexOrThrow(Phone.LOOKUP_KEY)
                val nameIndex = c.getColumnIndexOrThrow(Phone.DISPLAY_NAME)
                val phoneIndex = c.getColumnIndexOrThrow(Phone.NUMBER)
                while (c.moveToNext()) {
                    val key = c.getString(keyIndex).orEmpty()
                    val name = c.getString(nameIndex).orEmpty().trim()
                    val phone = c.getString(phoneIndex).orEmpty().trim()
                    if (name.isEmpty() && phone.isEmpty()) continue
                    if (seen.add(key + "|" + TextNorm.digitsOnly(phone))) {
                        result += PickedContact(key, name.ifEmpty { phone }, phone)
                    }
                }
            }

            // مخاطبینی که شماره ندارند
            resolver.query(
                Contacts.CONTENT_URI,
                arrayOf(Contacts.LOOKUP_KEY, Contacts.DISPLAY_NAME),
                "${Contacts.HAS_PHONE_NUMBER} = 0",
                null, null
            )?.use { c ->
                val keyIndex = c.getColumnIndexOrThrow(Contacts.LOOKUP_KEY)
                val nameIndex = c.getColumnIndexOrThrow(Contacts.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val key = c.getString(keyIndex).orEmpty()
                    val name = c.getString(nameIndex).orEmpty().trim()
                    if (name.isEmpty()) continue
                    if (seen.add("$key|")) result += PickedContact(key, name, "")
                }
            }
        } catch (e: SecurityException) {
            return@withContext emptyList<PickedContact>()
        } catch (e: Exception) {
            // خطای Provider: هر چه خوانده شده برگردانده می‌شود
        }
        val collator = Collator.getInstance(Locale("fa"))
        result.sortedWith(Comparator { a, b -> collator.compare(a.name, b.name) })
    }

    /** مخاطبی را که از برنامه‌ی مخاطبین برگشته (مثلاً بعد از ایجاد مخاطب جدید) به PickedContact تبدیل می‌کند. */
    suspend fun resolve(context: Context, uri: Uri): PickedContact? = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            var id = -1L
            var key = ""
            var name = ""
            resolver.query(
                uri,
                arrayOf(Contacts._ID, Contacts.LOOKUP_KEY, Contacts.DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    id = c.getLong(0)
                    key = c.getString(1).orEmpty()
                    name = c.getString(2).orEmpty()
                }
            }
            if (id < 0) return@withContext null
            var phone = ""
            resolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.NUMBER),
                "${Phone.CONTACT_ID} = ?",
                arrayOf(id.toString()),
                null
            )?.use { c ->
                if (c.moveToFirst()) phone = c.getString(0).orEmpty()
            }
            PickedContact(key, name.ifBlank { phone }, phone.trim())
        } catch (e: Exception) {
            null
        }
    }
}
