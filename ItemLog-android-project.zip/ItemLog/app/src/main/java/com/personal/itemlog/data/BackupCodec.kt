package com.personal.itemlog.data

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File

data class BackupData(
    val records: List<ItemRecord>,
    val attachments: List<Attachment>,
    val settings: Map<String, String>
)

/** قالب JSON پشتیبان: هم‌ارز با ساختار دیتابیس و مستقل از نسخه Room. */
object BackupCodec {
    const val FORMAT_VERSION = 1

    fun encode(
        records: List<ItemRecord>,
        attachments: List<Attachment>,
        settings: Map<String, String>,
        exportedAt: Long
    ): String {
        val root = JSONObject()
        root.put("app", "ItemLog")
        root.put("formatVersion", FORMAT_VERSION)
        root.put("exportedAt", exportedAt)

        val recordsJson = JSONArray()
        for (r in records) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("contactKey", r.contactKey)
            o.put("contactName", r.contactName)
            o.put("contactPhone", r.contactPhone)
            o.put("productCode", r.productCode)
            o.put("productName", r.productName)
            o.put("quantity", r.quantity)
            o.put("unit", r.unit)
            o.put("planningSite", r.planningSite)
            o.put("notes", r.notes)
            o.put("status", r.status)
            o.put("createdAt", r.createdAt)
            o.put("updatedAt", r.updatedAt)
            r.completedAt?.let { o.put("completedAt", it) }
            r.deletedAt?.let { o.put("deletedAt", it) }
            recordsJson.put(o)
        }
        root.put("records", recordsJson)

        val attachmentsJson = JSONArray()
        for (a in attachments) {
            val o = JSONObject()
            o.put("id", a.id)
            o.put("recordId", a.recordId)
            o.put("displayName", a.displayName)
            o.put("mimeType", a.mimeType)
            o.put("storedName", a.storedName)
            o.put("sizeBytes", a.sizeBytes)
            o.put("createdAt", a.createdAt)
            attachmentsJson.put(o)
        }
        root.put("attachments", attachmentsJson)

        val settingsJson = JSONObject()
        for ((k, v) in settings) settingsJson.put(k, v)
        root.put("settings", settingsJson)

        return root.toString()
    }

    /** در صورت نامعتبر بودن فایل، IllegalArgumentException پرتاب می‌شود. */
    fun decode(json: String): BackupData {
        try {
            val root = JSONObject(json)
            val version = root.optInt("formatVersion", 0)
            require(version in 1..FORMAT_VERSION) { "نسخه فایل پشتیبان پشتیبانی نمی‌شود" }

            val records = mutableListOf<ItemRecord>()
            val recordsJson = root.getJSONArray("records")
            for (i in 0 until recordsJson.length()) {
                val o = recordsJson.getJSONObject(i)
                records += ItemRecord(
                    id = o.getLong("id"),
                    contactKey = o.optString("contactKey", ""),
                    contactName = o.optString("contactName", ""),
                    contactPhone = o.optString("contactPhone", ""),
                    productCode = o.optString("productCode", ""),
                    productName = o.optString("productName", ""),
                    quantity = o.optString("quantity", ""),
                    unit = o.optString("unit", ""),
                    planningSite = o.optString("planningSite", ""),
                    notes = o.optString("notes", ""),
                    status = o.optString("status", STATUS_ACTIVE).let {
                        if (it == STATUS_DONE) STATUS_DONE else STATUS_ACTIVE
                    },
                    createdAt = o.optLong("createdAt", 0),
                    updatedAt = o.optLong("updatedAt", 0),
                    completedAt = optLongOrNull(o, "completedAt"),
                    deletedAt = optLongOrNull(o, "deletedAt")
                )
            }

            val attachments = mutableListOf<Attachment>()
            val attachmentsJson = root.optJSONArray("attachments") ?: JSONArray()
            for (i in 0 until attachmentsJson.length()) {
                val o = attachmentsJson.getJSONObject(i)
                attachments += Attachment(
                    id = o.getLong("id"),
                    recordId = o.getLong("recordId"),
                    displayName = o.optString("displayName", ""),
                    mimeType = o.optString("mimeType", ""),
                    storedName = File(o.getString("storedName")).name,
                    sizeBytes = o.optLong("sizeBytes", 0),
                    createdAt = o.optLong("createdAt", 0)
                )
            }

            val recordIds = records.map { it.id }.toSet()
            val validAttachments = attachments.filter { it.recordId in recordIds }

            val settings = mutableMapOf<String, String>()
            val settingsJson = root.optJSONObject("settings")
            if (settingsJson != null) {
                for (key in settingsJson.keys()) settings[key] = settingsJson.optString(key, "")
            }
            return BackupData(records, validAttachments, settings)
        } catch (e: JSONException) {
            throw IllegalArgumentException("فایل پشتیبان معتبر نیست", e)
        }
    }

    private fun optLongOrNull(o: JSONObject, key: String): Long? =
        if (o.has(key) && !o.isNull(key)) o.getLong(key) else null
}
