@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog.ui

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.personal.itemlog.data.ContactsSource
import com.personal.itemlog.domain.PickedContact
import kotlinx.coroutines.launch

/** انتخاب مخاطب از مخاطبین گوشی (Google Contacts و مخاطبین ذخیره‌شده روی دستگاه) با جستجوی سریع. */
@Composable
fun ContactPickerDialog(onDismiss: () -> Unit, onPicked: (PickedContact) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(ContactsSource.hasPermission(context)) }
    var contacts by remember { mutableStateOf<List<PickedContact>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf(false) }
    var reloadTick by remember { mutableIntStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
        if (!it) manual = true
    }
    LaunchedEffect(Unit) {
        if (!granted) permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
    }
    LaunchedEffect(granted, reloadTick) {
        if (granted) {
            loading = true
            contacts = ContactsSource.loadAll(context)
            loading = false
        }
    }

    val insertLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        scope.launch {
            if (result.resultCode == Activity.RESULT_OK && uri != null) {
                ContactsSource.resolve(context, uri)?.let { onPicked(it) }
            }
            reloadTick++
        }
    }

    val filtered = remember(contacts, query) {
        if (query.isBlank()) contacts else contacts.filter { it.matches(query) }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "بستن") }
                    Text("انتخاب مخاطب", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                if (granted) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        singleLine = true,
                        placeholder = { Text("جستجو با نام، نام خانوادگی یا شماره") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) { Icon(Icons.Default.Clear, contentDescription = "پاک کردن") }
                            }
                        }
                    )
                }
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI).apply {
                                val q = query.trim()
                                if (q.isNotEmpty()) {
                                    if (q.any { it.isLetter() }) putExtra(ContactsContract.Intents.Insert.NAME, q)
                                    else putExtra(ContactsContract.Intents.Insert.PHONE, q)
                                }
                                putExtra("finishActivityOnSaveCompleted", true)
                            }
                            try {
                                insertLauncher.launch(intent)
                            } catch (e: ActivityNotFoundException) {
                                Toast.makeText(context, "برنامه‌ی مخاطبین پیدا نشد", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("مخاطب جدید") }
                    OutlinedButton(onClick = { manual = !manual }, modifier = Modifier.weight(1f)) {
                        Text(if (manual) "بستن ورود دستی" else "ورود دستی")
                    }
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

                if (manual || !granted) {
                    ManualContactEntry(
                        showPermissionHint = !granted,
                        onAskPermission = { permissionLauncher.launch(Manifest.permission.READ_CONTACTS) },
                        onConfirm = onPicked
                    )
                }

                if (granted) {
                    if (!loading && filtered.isEmpty()) {
                        Text(
                            if (contacts.isEmpty()) "مخاطبی روی گوشی پیدا نشد." else "نتیجه‌ای پیدا نشد.",
                            modifier = Modifier.padding(24.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(filtered) { c ->
                            Column(Modifier.fillMaxWidth()) {
                                Column(
                                    Modifier.fillMaxWidth().clickable { onPicked(c) }.padding(horizontal = 16.dp, vertical = 10.dp)
                                ) {
                                    Text(c.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    if (c.phone.isNotBlank()) {
                                        Text(c.phone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManualContactEntry(
    showPermissionHint: Boolean,
    onAskPermission: () -> Unit,
    onConfirm: (PickedContact) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (showPermissionHint) {
            Text(
                "برای دیدن مخاطبین گوشی، اجازه‌ی دسترسی به مخاطبین لازم است. می‌توانید نام و شماره را دستی وارد کنید.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = onAskPermission) { Text("اجازه‌ی دسترسی به مخاطبین") }
        }
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام مخاطب") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = phone, onValueChange = { phone = it }, label = { Text("شماره تلفن") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )
        Button(
            enabled = name.isNotBlank() || phone.isNotBlank(),
            onClick = { onConfirm(PickedContact("", name.trim().ifEmpty { phone.trim() }, phone.trim())) }
        ) { Text("تأیید مخاطب") }
    }
}
