package com.personal.itemlog.domain

import com.personal.itemlog.data.ItemRecord
import java.time.LocalDate
import java.time.ZoneId

/** قالب پیامک: متن ابتدایی (و متن پایانی اختیاری)؛ فقط آیتم‌های کالا بین این دو درج می‌شود. */
data class SmsTemplate(
    val id: String,
    val name: String,
    val header: String,
    val footer: String = ""
)

enum class SmsItemStyle(val key: String, val label: String) {
    DETAILED("detailed", "تفکیکی"),
    COMPACT("compact", "فشرده");

    companion object {
        fun fromKey(key: String?): SmsItemStyle = entries.firstOrNull { it.key == key } ?: DETAILED
    }
}

object DefaultTemplates {
    const val DEFAULT_ID = "default-info"

    fun create(): List<SmsTemplate> = listOf(
        SmsTemplate(DEFAULT_ID, "اطلاع‌رسانی اقلام", "سلام {نام} عزیز\nلیست اقلام ثبت‌شده برای {تاریخ}:"),
        SmsTemplate("default-followup", "یادآوری پیگیری", "سلام {نام} عزیز\nاقلام زیر هنوز در حال پیگیری است:"),
        SmsTemplate("default-done", "تکمیل اقلام", "سلام {نام} عزیز\nاقلام زیر تکمیل شد:", "با تشکر")
    )
}

object SmsBuilder {
    const val NAME = "{نام}"
    const val DATE = "{تاریخ}"
    const val COUNT = "{تعداد}"
    val PLACEHOLDERS = listOf(NAME, DATE, COUNT)

    fun applyPlaceholders(text: String, name: String, dateLabel: String, count: Int): String {
        var t = text
        val n = name.trim()
        if (n.isEmpty()) {
            t = t.replace(" $NAME عزیز", "").replace("$NAME عزیز", "")
        }
        t = t.replace(NAME, n)
            .replace(DATE, dateLabel)
            .replace(COUNT, TextNorm.toPersianDigits(count.toString()))
        t = t.replace(Regex(" {2,}"), " ")
        return t.lines().joinToString("\n") { it.trimEnd() }.trim()
    }

    fun dateLabel(dates: List<LocalDate>): String = when {
        dates.isEmpty() -> ""
        dates.size == 1 -> Jalali.formatDate(dates.first())
        else -> "از ${Jalali.formatDate(dates.first())} تا ${Jalali.formatDate(dates.last())}"
    }

    fun itemBlock(r: ItemRecord, index: Int, style: SmsItemStyle): String {
        val n = TextNorm.toPersianDigits(index.toString())
        val name = r.productName.trim()
        val codeValue = r.productCode.trim()
        val title = name.ifEmpty { codeValue.ifEmpty { "—" } }
        val code = if (name.isNotEmpty()) codeValue else ""
        val qty = listOf(r.quantity.trim(), r.unit.trim()).filter { it.isNotEmpty() }.joinToString(" ")
        val site = r.planningSite.trim()
        val notes = r.notes.trim()
        return when (style) {
            SmsItemStyle.DETAILED -> buildString {
                append("$n) $title")
                if (code.isNotEmpty()) append("\n   کد کالا: $code")
                if (qty.isNotEmpty()) append("\n   تعداد: $qty")
                if (site.isNotEmpty()) append("\n   سایت برنامه‌ریزی: $site")
                if (notes.isNotEmpty()) append("\n   توضیحات: $notes")
                if (r.isDone) append("\n   وضعیت: اتمام")
            }
            SmsItemStyle.COMPACT -> buildString {
                append("$n) $title")
                if (code.isNotEmpty()) append(" (کد $code)")
                if (qty.isNotEmpty()) append(" — $qty")
                if (site.isNotEmpty()) append(" | سایت: $site")
                if (notes.isNotEmpty()) append(" | $notes")
                if (r.isDone) append(" | اتمام")
            }
        }
    }

    /** متن قالب + فهرست آیتم‌ها (+ متن پایانی). فیلدهای خالی هرگز نمایش داده نمی‌شوند. */
    fun render(
        template: SmsTemplate,
        contactName: String,
        records: List<ItemRecord>,
        style: SmsItemStyle,
        zone: ZoneId = ZoneId.systemDefault()
    ): String {
        val sorted = records.filter { it.deletedAt == null }.sortedBy { it.createdAt }
        val byDate = sorted.groupBy { Jalali.dateOf(it.createdAt, zone) }
        val dates = byDate.keys.toList()
        val label = dateLabel(dates)
        val header = applyPlaceholders(template.header, contactName, label, sorted.size)
        val footer = applyPlaceholders(template.footer, contactName, label, sorted.size)

        val parts = mutableListOf<String>()
        if (header.isNotEmpty()) parts += header
        var index = 0
        for (date in dates) {
            if (dates.size > 1) parts += "— ${Jalali.formatDate(date)} —"
            val blocks = byDate.getValue(date).map { r -> index++; itemBlock(r, index, style) }
            parts += blocks.joinToString(if (style == SmsItemStyle.DETAILED) "\n\n" else "\n")
        }
        if (footer.isNotEmpty()) parts += footer
        return parts.joinToString("\n\n")
    }
}
