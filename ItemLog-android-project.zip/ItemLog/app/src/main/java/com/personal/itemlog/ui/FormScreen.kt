@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.personal.itemlog.ItemLogApp
import com.personal.itemlog.data.Attachment
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_ACTIVE
import com.personal.itemlog.data.STATUS_DONE
import com.personal.itemlog.domain.PickedContact
import com.personal.itemlog.domain.SpeechText
import com.personal.itemlog.domain.Suggestions
import com.personal.itemlog.domain.hasContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** حالت فرم؛ همه‌ی فیلدها در ابتدا خالی‌اند. */
class FormState {
    var contactKey by mutableStateOf("")
    var contactName by mutableStateOf("")
    var contactPhone by mutableStateOf("")
    var productCode by mutableStateOf("")
    var productName by mutableStateOf("")
    var quantity by mutableStateOf("")
    var unit by mutableStateOf("")
    var planningSite by mutableStateOf("")
    var notes by mutableStateOf("")
    var status by mutableStateOf(STATUS_ACTIVE)
    val attachments = mutableStateListOf<Attachment>()
    val removedIds = mutableListOf<Long>()
    var original: ItemRecord? = null
    var baseline: String = ""

    fun fill(record: ItemRecord, existing: List<Attachment>, keepOriginal: Boolean) {
        contactKey = record.contactKey
        contactName = record.contactName
        contactPhone = record.contactPhone
        productCode = record.productCode
        productName = record.productName
        quantity = record.quantity
        unit = record.unit
        planningSite = record.planningSite
        notes = record.notes
        status = if (keepOriginal) record.status else STATUS_ACTIVE
        attachments.clear()
        attachments.addAll(existing)
        removedIds.clear()
        original = if (keepOriginal) record else null
        baseline = signature()
    }

    fun setContact(c: PickedContact?) {
        contactKey = c?.lookupKey.orEmpty()
        contactName = c?.name.orEmpty()
        contactPhone = c?.phone.orEmpty()
    }

    fun signature(): String = listOf(
        contactKey, contactName, contactPhone, productCode, productName, quantity, unit,
        planningSite, notes, status, attachments.joinToString(",") { it.storedName },
        removedIds.joinToString(",")
    ).joinToString("\u0001")

    val isDirty: Boolean get() = signature() != baseline

    fun toRecord(): ItemRecord = (original ?: ItemRecord()).copy(
        contactKey = contactKey,
        contactName = contactName.trim(),
        contactPhone = contactPhone.trim(),
        productCode = productCode.trim(),
        productName = productName.trim(),
        quantity = quantity.trim(),
        unit = unit.trim(),
        planningSite = planningSite.trim(),
        notes = notes.trim(),
        status = status
    )

    /** بعد از «ذخیره و بعدی»: مخاطب می‌ماند و بقیه‌ی فیلدها خالی می‌شوند. */
    fun resetForNext() {
        productCode = ""
        productName = ""
        quantity = ""
        unit = ""
        planningSite = ""
        notes = ""
        status = STATUS_ACTIVE
        attachments.clear()
        removedIds.clear()
        original = null
        baseline = signature()
    }
}

@Composable
fun FormScreen(recordId: Long, duplicateFrom: Long, contactFrom: Long, vm: MainViewModel, onClose: () -> Unit) {
    val context = LocalContext.current
    val store = (context.applicationContext as ItemLogApp).fileStore
    val scope = rememberCoroutineScope()
    val state = remember { FormState().also { it.baseline = it.signature() } }
    val isEdit = recordId != 0L
    var loaded by remember { mutableStateOf(!isEdit && duplicateFrom == 0L && contactFrom == 0L) }
    val siteSuggestions by vm.siteSuggestions.collectAsStateWithLifecycle()
    val unitSuggestions by vm.unitSuggestions.collectAsStateWithLifecycle()
    var showContactPicker by remember { mutableStateOf(false) }
    var viewingImage by remember { mutableStateOf<Attachment?>(null) }
    var confirmDiscard by remember { mutableStateOf(false) }

    LaunchedEffect(recordId, duplicateFrom, contactFrom) {
        if (!loaded) {
            val sourceId = when {
                isEdit -> recordId
                duplicateFrom != 0L -> duplicateFrom
                else -> contactFrom
            }
            val source = vm.loadRecord(sourceId)
            if (source != null) {
                if (isEdit || duplicateFrom != 0L) {
                    state.fill(source.record, if (isEdit) source.attachments else emptyList(), keepOriginal = isEdit)
                } else {
                    // ثبت کالای جدید برای همان مخاطب: فقط اطلاعات مخاطب کپی می‌شود
                    state.setContact(
                        PickedContact(source.record.contactKey, source.record.contactName, source.record.contactPhone)
                    )
                    state.baseline = state.signature()
                }
            }
            loaded = true
        } else {
            state.baseline = state.signature()
        }
    }

    fun toast(text: String) = Toast.makeText(context, text, Toast.LENGTH_SHORT).show()

    fun close(discard: Boolean) {
        if (discard) vm.discardDrafts(state.attachments.toList())
        onClose()
    }

    fun requestClose() {
        if (state.isDirty) confirmDiscard = true else close(discard = true)
    }

    BackHandler { requestClose() }

    // ----- گفتار به متن -----
    var pendingSpeech by remember { mutableStateOf<((String) -> Unit)?>(null) }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) pendingSpeech?.invoke(text)
        }
        pendingSpeech = null
    }
    fun listen(onText: (String) -> Unit) {
        pendingSpeech = onText
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "صحبت کنید…")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            pendingSpeech = null
            toast("سرویس تبدیل گفتار به متن روی این گوشی در دسترس نیست")
        }
    }

    // ----- پیوست‌ها -----
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val attachment = withContext(Dispatchers.IO) { store.importFromUri(uri) }
                if (attachment != null) state.attachments.add(attachment) else toast("افزودن فایل انجام نشد")
            }
        }
    }
    var cameraFile by remember { mutableStateOf<File?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val file = cameraFile
        if (ok && file != null && file.exists() && file.length() > 0) {
            state.attachments.add(store.cameraAttachment(file))
        } else {
            file?.delete()
        }
        cameraFile = null
    }

    fun save(next: Boolean) {
        val record = state.toRecord()
        if (!record.hasContent() && state.attachments.isEmpty()) {
            toast("حداقل یک فیلد را پر کنید")
            return
        }
        vm.save(
            record,
            state.attachments.filter { it.id == 0L },
            state.removedIds.toSet()
        ) {
            toast("ذخیره شد")
            if (next) state.resetForNext() else onClose()
        }
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when {
                            isEdit -> "ویرایش رکورد"
                            duplicateFrom != 0L -> "تکرار رکورد"
                            contactFrom != 0L -> "کالای جدید برای مخاطب"
                            else -> "ثبت کالا"
                        }
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { requestClose() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!isEdit) {
                        OutlinedButton(onClick = { save(next = true) }, modifier = Modifier.weight(1f)) {
                            Text("ذخیره و بعدی")
                        }
                    }
                    Button(onClick = { save(next = false) }, modifier = Modifier.weight(1f)) { Text("ذخیره") }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionCard("مخاطب") {
                ContactField(
                    name = state.contactName,
                    phone = state.contactPhone,
                    onPick = { showContactPicker = true },
                    onClear = { state.setContact(null) }
                )
            }

            SectionCard("اطلاعات کالا") {
                OutlinedTextField(
                    value = state.productCode, onValueChange = { state.productCode = it },
                    label = { Text("کد کالا") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                MicTextField(
                    value = state.productName, onValueChange = { state.productName = it },
                    label = "نام کالا", onMic = { listen { state.productName = SpeechText.merge(state.productName, it) } }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = state.quantity, onValueChange = { state.quantity = it },
                        label = { Text("تعداد") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = state.unit, onValueChange = { state.unit = it },
                        label = { Text("واحد کالا") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                }
                SuggestionRow(remember(unitSuggestions, state.unit) { Suggestions.filter(unitSuggestions, state.unit) }) {
                    state.unit = it
                }
            }

            SectionCard("سایت و توضیحات") {
                MicTextField(
                    value = state.planningSite, onValueChange = { state.planningSite = it },
                    label = "سایت برنامه‌ریزی", onMic = { listen { state.planningSite = SpeechText.merge(state.planningSite, it) } }
                )
                SuggestionRow(remember(siteSuggestions, state.planningSite) { Suggestions.filter(siteSuggestions, state.planningSite) }) {
                    state.planningSite = it
                }
                MicTextField(
                    value = state.notes, onValueChange = { state.notes = it },
                    label = "توضیحات", minLines = 3,
                    onMic = { listen { state.notes = SpeechText.merge(state.notes, it) } }
                )
            }

            if (isEdit) {
                SectionCard("وضعیت") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = state.status == STATUS_ACTIVE, onClick = { state.status = STATUS_ACTIVE }, label = { Text("فعال") })
                        FilterChip(selected = state.status == STATUS_DONE, onClick = { state.status = STATUS_DONE }, label = { Text("اتمام") })
                    }
                }
            }

            SectionCard("پیوست‌ها") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickFile.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                        Text("📎 افزودن فایل")
                    }
                    OutlinedButton(
                        onClick = {
                            val file = store.newCameraFile()
                            cameraFile = file
                            try {
                                camera.launch(store.uriFor(file))
                            } catch (e: ActivityNotFoundException) {
                                cameraFile = null
                                toast("برنامه‌ی دوربین پیدا نشد")
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("📷 عکس") }
                }
                AttachmentList(
                    attachments = state.attachments.toList(),
                    onOpen = { openAttachment(context, it) { img -> viewingImage = img } },
                    onRemove = { a ->
                        state.attachments.remove(a)
                        if (a.id != 0L) state.removedIds.add(a.id) else store.delete(a.storedName)
                    }
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showContactPicker) {
        ContactPickerDialog(
            onDismiss = { showContactPicker = false },
            onPicked = {
                state.setContact(it)
                showContactPicker = false
            }
        )
    }

    viewingImage?.let { ImageViewerDialog(it) { viewingImage = null } }

    if (confirmDiscard) {
        AlertDialog(
            onDismissRequest = { confirmDiscard = false },
            title = { Text("خروج بدون ذخیره؟") },
            text = { Text("تغییرات ذخیره‌نشده از بین می‌روند.") },
            confirmButton = {
                TextButton(onClick = { confirmDiscard = false; close(discard = true) }) { Text("خروج") }
            },
            dismissButton = { TextButton(onClick = { confirmDiscard = false }) { Text("ادامه ویرایش") } }
        )
    }
}

@Composable
private fun ContactField(name: String, phone: String, onPick: () -> Unit, onClear: () -> Unit) {
    OutlinedCard(Modifier.fillMaxWidth().clickable(onClick = onPick)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                if (name.isBlank() && phone.isBlank()) {
                    Text("انتخاب مخاطب", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text(name.ifBlank { phone }, fontWeight = FontWeight.Bold)
                    if (name.isNotBlank() && phone.isNotBlank()) {
                        Text(phone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (name.isNotBlank() || phone.isNotBlank()) {
                IconButton(onClick = onClear) { Icon(Icons.Default.Clear, contentDescription = "حذف مخاطب") }
            }
        }
    }
}

@Composable
private fun MicTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    onMic: () -> Unit,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        minLines = minLines,
        singleLine = minLines == 1,
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
        trailingIcon = {
            IconButton(onClick = onMic) { Text("🎤") }
        }
    )
}
