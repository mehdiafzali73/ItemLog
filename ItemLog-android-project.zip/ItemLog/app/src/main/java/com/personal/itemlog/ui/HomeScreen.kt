@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personal.itemlog.data.Attachment
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.RecordGroup
import com.personal.itemlog.domain.StatusFilter
import com.personal.itemlog.domain.TextNorm
import com.personal.itemlog.domain.computeStats
import com.personal.itemlog.domain.displayTitle
import com.personal.itemlog.domain.isDone
import java.time.LocalDate
import java.time.ZoneId

private sealed interface HomeRow {
    val key: String

    data class Header(val group: RecordGroup) : HomeRow {
        override val key: String get() = "g|${group.contactKey}|${group.date}"
    }

    data class Rec(val id: Long, val group: RecordGroup) : HomeRow {
        override val key: String get() = "r|$id"
    }
}

private fun dayLabel(date: LocalDate, today: LocalDate): String = when (date) {
    today -> "امروز — " + Jalali.formatDate(date)
    today.minusDays(1) -> "دیروز — " + Jalali.formatDate(date)
    else -> Jalali.weekdayName(date) + " " + Jalali.formatDate(date)
}

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onNew: () -> Unit,
    onEdit: (Long) -> Unit,
    onDuplicate: (Long) -> Unit
) {
    val groups by vm.homeGroups.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    val attachments by vm.attachmentsByRecord.collectAsStateWithLifecycle()
    val search by vm.homeSearch.collectAsStateWithLifecycle()
    val status by vm.homeStatus.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val stats = remember(records, today) { computeStats(records, today, ZoneId.systemDefault()) }
    var viewingImage by remember { mutableStateOf<Attachment?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current

    val rows = remember(groups) {
        buildList<HomeRow> {
            for (g in groups) {
                add(HomeRow.Header(g))
                for (r in g.records) add(HomeRow.Rec(r.id, g))
            }
        }
    }

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("ثبت کالا") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNew,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("ثبت کالا") }
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item(key = "today") {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "امروز، " + Jalali.weekdayName(today),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            Jalali.formatDate(today),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Row(
                            Modifier.fillMaxWidth().padding(top = 12.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            StatBox("رکورد فعال", stats.activeCount)
                            StatBox("ثبت امروز", stats.todayCount)
                            StatBox("نیازمند پیگیری", stats.followUp.size)
                        }
                    }
                }
            }

            item(key = "search") {
                OutlinedTextField(
                    value = search,
                    onValueChange = { vm.homeSearch.value = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("جستجو در کالا، مخاطب، شماره، توضیحات…") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (search.isNotEmpty()) {
                            IconButton(onClick = { vm.homeSearch.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "پاک کردن")
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
                )
            }

            item(key = "chips") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusFilterChips(status) { vm.homeStatus.value = it }
                }
            }

            if (stats.followUp.isNotEmpty() && search.isBlank() && status != StatusFilter.DONE) {
                item(key = "followup") {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "نیازمند پیگیری (فعال از روزهای قبل)",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            stats.followUp.take(5).forEach { r ->
                                Text(
                                    "• " + listOf(r.contactName.trim(), r.displayTitle()).filter { it.isNotEmpty() }
                                        .joinToString(" — ") + "  (" + Jalali.formatDate(r.createdAt) + ")",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                            if (stats.followUp.size > 5) {
                                Text(
                                    "و " + TextNorm.toPersianDigits((stats.followUp.size - 5).toString()) + " مورد دیگر",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }
            }

            if (rows.isEmpty()) {
                item(key = "empty") {
                    Text(
                        if (search.isNotBlank()) "موردی پیدا نشد." else "هنوز رکوردی ثبت نشده است.\nبرای شروع دکمه‌ی «ثبت کالا» را بزنید.",
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            items(rows, key = { it.key }) { row ->
                when (row) {
                    is HomeRow.Header -> {
                        val g = row.group
                        Column(Modifier.padding(top = 8.dp, start = 4.dp)) {
                            Text(
                                listOf(g.contactName.trim(), g.contactPhone.trim()).filter { it.isNotEmpty() }
                                    .joinToString(" — ").ifEmpty { "بدون مخاطب" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                dayLabel(g.date, today),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    is HomeRow.Rec -> {
                        val record = row.group.records.first { it.id == row.id }
                        RecordCard(
                            record = record,
                            attachments = attachments[record.id].orEmpty(),
                            onEdit = { onEdit(record.id) },
                            onToggleDone = { if (record.isDone) vm.reopen(record.id) else vm.complete(record.id) },
                            onDuplicate = { onDuplicate(record.id) },
                            onDelete = { vm.delete(record.id) },
                            onOpenAttachment = { openAttachment(context, it) { img -> viewingImage = img } }
                        )
                    }
                }
            }
        }
    }

    viewingImage?.let { ImageViewerDialog(it) { viewingImage = null } }
}

@Composable
private fun StatBox(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            TextNorm.toPersianDigits(value.toString()),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun StatusFilterChips(selected: StatusFilter, onSelect: (StatusFilter) -> Unit) {
    val options = listOf(StatusFilter.ALL to "همه", StatusFilter.ACTIVE to "فعال", StatusFilter.DONE to "اتمام")
    options.forEach { (value, label) ->
        FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(label) })
    }
}
