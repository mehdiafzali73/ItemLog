@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personal.itemlog.data.Attachment
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.RecordGroup
import com.personal.itemlog.domain.StatusFilter
import com.personal.itemlog.domain.TextNorm
import com.personal.itemlog.domain.computeStats
import com.personal.itemlog.domain.contactIdentity
import com.personal.itemlog.domain.displayTitle
import com.personal.itemlog.domain.isDone
import com.personal.itemlog.export.ShareUtil
import java.time.LocalDate
import java.time.ZoneId

private sealed interface HomeRow {
    val key: String

    data class Header(val group: RecordGroup) : HomeRow {
        override val key: String get() = "g|${group.contactKey}|${group.date}"
    }

    data class Rec(val id: Long, val group: RecordGroup) : HomeRow {
        override val key: String get() = "r|$id"
    }
}

private class ConfirmAction(val title: String, val message: String, val confirmLabel: String, val onConfirm: () -> Unit)

private fun groupKey(g: RecordGroup) = "${g.contactKey}|${g.date}"

private fun dayLabel(date: LocalDate, today: LocalDate): String = when (date) {
    today -> "امروز — " + Jalali.formatDate(date)
    today.minusDays(1) -> "دیروز — " + Jalali.formatDate(date)
    else -> Jalali.weekdayName(date) + " " + Jalali.formatDate(date)
}

private fun count(n: Int) = TextNorm.toPersianDigits(n.toString())

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onNew: () -> Unit,
    onEdit: (Long) -> Unit,
    onDuplicate: (Long) -> Unit,
    onAddForContact: (Long) -> Unit
) {
    val groups by vm.homeGroups.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    val attachments by vm.attachmentsByRecord.collectAsStateWithLifecycle()
    val search by vm.homeSearch.collectAsStateWithLifecycle()
    val status by vm.homeStatus.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val stats = remember(records, today) { computeStats(records, today, ZoneId.systemDefault()) }
    var viewingImage by remember { mutableStateOf<Attachment?>(null) }
    var sheetKey by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<ConfirmAction?>(null) }
    val context = LocalContext.current
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    val rows = remember(groups) {
        buildList<HomeRow> {
            for (g in groups) {
                add(HomeRow.Header(g))
                for (r in g.records) add(HomeRow.Rec(r.id, g))
            }
        }
    }
    val sheetGroup = sheetKey?.let { key -> groups.firstOrNull { groupKey(it) == key } }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = { LargeTopAppBar(title = { Text("ثبت کالا") }, scrollBehavior = scrollBehavior) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNew,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("ثبت کالا") }
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, top = 4.dp, end = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item(key = "summary") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "امروز · " + Jalali.weekdayName(today) + " " + Jalali.formatDate(today),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("فعال", stats.activeCount, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer, Modifier.weight(1f))
                        StatCard("ثبت امروز", stats.todayCount, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer, Modifier.weight(1f))
                        StatCard("نیازمند پیگیری", stats.followUp.size, MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer, Modifier.weight(1f))
                    }
                }
            }

            item(key = "search") {
                OutlinedTextField(
                    value = search,
                    onValueChange = { vm.homeSearch.value = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    placeholder = { Text("جستجو در کالا، مخاطب، شماره، توضیحات…") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (search.isNotEmpty()) {
                            IconButton(onClick = { vm.homeSearch.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "پاک کردن")
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
                )
            }

            item(key = "chips") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusFilterChips(status) { vm.homeStatus.value = it }
                }
            }

            if (stats.followUp.isNotEmpty() && search.isBlank() && status != StatusFilter.DONE) {
                item(key = "followup") {
                    OutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "نیازمند پیگیری · فعال از روزهای قبل",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                            stats.followUp.take(5).forEach { r ->
                                Text(
                                    "• " + listOf(r.contactName.trim(), r.displayTitle()).filter { it.isNotEmpty() }
                                        .joinToString(" — ") + "  (" + Jalali.formatDate(r.createdAt) + ")",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (stats.followUp.size > 5) {
                                Text(
                                    "و " + count(stats.followUp.size - 5) + " مورد دیگر",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            if (rows.isEmpty()) {
                item(key = "empty") {
                    if (search.isNotBlank()) {
                        EmptyState("🔍", "موردی پیدا نشد", "عبارت دیگری را جستجو کنید.")
                    } else {
                        EmptyState("🗂️", "هنوز رکوردی ثبت نشده", "برای شروع دکمه‌ی «ثبت کالا» را بزنید.")
                    }
                }
            }

            items(rows, key = { it.key }) { row ->
                when (row) {
                    is HomeRow.Header -> ContactHeader(
                        group = row.group,
                        today = today,
                        onClick = { sheetKey = groupKey(row.group) }
                    )
                    is HomeRow.Rec -> {
                        val record = row.group.records.first { it.id == row.id }
                        RecordCard(
                            record = record,
                            attachments = attachments[record.id].orEmpty(),
                            onEdit = { onEdit(record.id) },
                            onToggleDone = { if (record.isDone) vm.reopen(record.id) else vm.complete(record.id) },
                            onDuplicate = { onDuplicate(record.id) },
                            onDelete = { vm.delete(record.id) },
                            onOpenAttachment = { openAttachment(context, it) { img -> viewingImage = img } }
                        )
                    }
                }
            }
        }
    }

    if (sheetGroup != null) {
        val g = sheetGroup
        val identity = g.contactKey
        val hasContact = identity.isNotEmpty()
        val allOfContact = records.filter { it.deletedAt == null && (it.contactIdentity() ?: "") == identity }
        val dayItems = allOfContact.filter { Jalali.dateOf(it.createdAt) == g.date }
        val activeVisible = g.records.filter { !it.isDone }

        ModalBottomSheet(onDismissRequest = { sheetKey = null }, sheetState = rememberModalBottomSheetState()) {
            Column(Modifier.padding(bottom = 16.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AvatarCircle(g.contactName.ifBlank { g.contactPhone }, diameter = 48.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(
                            listOf(g.contactName.trim()).filter { it.isNotEmpty() }.firstOrNull() ?: g.contactPhone.ifBlank { "بدون مخاطب" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        val sub = listOf(
                            if (g.contactName.isNotBlank()) g.contactPhone.trim() else "",
                            dayLabel(g.date, today)
                        ).filter { it.isNotEmpty() }.joinToString("  •  ")
                        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 4.dp))

                if (hasContact) {
                    SheetAction(Icons.Default.Add, "افزودن کالای جدید برای این مخاطب") {
                        sheetKey = null
                        onAddForContact(g.records.first().id)
                    }
                }
                if (activeVisible.isNotEmpty()) {
                    SheetAction(Icons.Default.Done, "اتمام همه‌ی موارد فعال این گروه (" + count(activeVisible.size) + ")") {
                        sheetKey = null
                        vm.completeMany(activeVisible.map { it.id })
                    }
                }
                if (g.contactPhone.isNotBlank()) {
                    SheetAction(Icons.Default.Send, "ارسال پیامک این گروه (قالب پیش‌فرض)") {
                        sheetKey = null
                        ShareUtil.composeSms(context, g.contactPhone, vm.buildSms(null, g.contactName, g.records))
                    }
                }
                val error = MaterialTheme.colorScheme.error
                SheetAction(Icons.Default.Delete, "حذف همه‌ی موارد این تاریخ (" + count(dayItems.size) + ")", error) {
                    val ids = dayItems.map { it.id }
                    confirm = ConfirmAction(
                        "حذف موارد این تاریخ؟",
                        count(ids.size) + " رکورد از " + dayLabel(g.date, today) + " حذف می‌شود. تا چند ثانیه می‌توانید با «واگرد» برگردانید و بعد از آن از «حذف‌شده‌ها» در تنظیمات.",
                        "حذف"
                    ) { vm.deleteMany(ids) }
                    sheetKey = null
                }
                if (hasContact && allOfContact.size > dayItems.size) {
                    SheetAction(Icons.Default.Delete, "حذف همه‌ی موارد این مخاطب در همه‌ی تاریخ‌ها (" + count(allOfContact.size) + ")", error) {
                        val ids = allOfContact.map { it.id }
                        confirm = ConfirmAction(
                            "حذف همه‌ی موارد مخاطب؟",
                            count(ids.size) + " رکورد مربوط به " + g.contactName.ifBlank { g.contactPhone } + " در همه‌ی تاریخ‌ها حذف می‌شود. از «حذف‌شده‌ها» قابل بازگردانی است.",
                            "حذف همه"
                        ) { vm.deleteMany(ids) }
                        sheetKey = null
                    }
                }
            }
        }
    }

    confirm?.let { action ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(action.title) },
            text = { Text(action.message) },
            confirmButton = {
                TextButton(onClick = { confirm = null; action.onConfirm() }) {
                    Text(action.confirmLabel, color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("انصراف") } }
        )
    }

    viewingImage?.let { ImageViewerDialog(it) { viewingImage = null } }
}

@Composable
private fun ContactHeader(group: RecordGroup, today: LocalDate, onClick: () -> Unit) {
    val title = group.contactName.trim().ifEmpty { group.contactPhone.trim().ifEmpty { "بدون مخاطب" } }
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerHighest,
        modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AvatarCircle(title)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                if (group.contactName.isNotBlank() && group.contactPhone.isNotBlank()) {
                    Text(group.contactPhone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(dayLabel(group.date, today), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    count(group.records.size) + " مورد",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "گزینه‌های مخاطب", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SheetAction(icon: ImageVector, text: String, tint: Color = Color.Unspecified, onClick: () -> Unit) {
    val color = if (tint == Color.Unspecified) MaterialTheme.colorScheme.onSurface else tint
    ListItem(
        headlineContent = { Text(text, color = color) },
        leadingContent = { Icon(icon, contentDescription = null, tint = color) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick)
    )
}

@Composable
private fun StatCard(label: String, value: Int, container: Color, content: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = container, contentColor = content)) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(count(value), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

@Composable
fun StatusFilterChips(selected: StatusFilter, onSelect: (StatusFilter) -> Unit) {
    val options = listOf(StatusFilter.ALL to "همه", StatusFilter.ACTIVE to "فعال", StatusFilter.DONE to "اتمام")
    options.forEach { (value, label) ->
        FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(label) })
    }
}
