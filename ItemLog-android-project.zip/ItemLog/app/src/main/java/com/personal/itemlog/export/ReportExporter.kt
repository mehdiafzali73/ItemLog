package com.personal.itemlog.export

import android.content.Context
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.domain.RecordGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** فایل‌های PDF و Excel را در پوشه‌ی موقت برنامه می‌سازد تا با Share ارسال شوند. */
class ReportExporter(private val context: Context) {
    private fun exportDir(): File {
        val dir = File(context.cacheDir, "exports").also { it.mkdirs() }
        val cutoff = System.currentTimeMillis() - 24L * 3600 * 1000
        dir.listFiles()?.filter { it.lastModified() < cutoff }?.forEach { it.delete() }
        return dir
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    suspend fun createPdf(title: String, subtitle: String, groups: List<RecordGroup>): File =
        withContext(Dispatchers.IO) {
            val file = File(exportDir(), "itemlog_report_${stamp()}.pdf")
            file.outputStream().use { PdfReport(context).write(it, title, subtitle, groups) }
            file
        }

    suspend fun createXlsx(records: List<ItemRecord>): File =
        withContext(Dispatchers.IO) {
            val file = File(exportDir(), "itemlog_report_${stamp()}.xlsx")
            file.outputStream().use {
                XlsxWriter.write(it, "گزارش", ExcelRows.HEADERS, ExcelRows.rows(records))
            }
            file
        }
}
