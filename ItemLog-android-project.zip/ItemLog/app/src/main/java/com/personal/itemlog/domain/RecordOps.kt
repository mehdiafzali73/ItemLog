package com.personal.itemlog.domain

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_ACTIVE
import com.personal.itemlog.data.STATUS_DONE

val ItemRecord.isDone: Boolean get() = status == STATUS_DONE
val ItemRecord.isDeleted: Boolean get() = deletedAt != null

fun ItemRecord.markDone(now: Long): ItemRecord =
    copy(status = STATUS_DONE, completedAt = now, updatedAt = now)

fun ItemRecord.reopen(now: Long): ItemRecord =
    copy(status = STATUS_ACTIVE, completedAt = null, updatedAt = now)

fun ItemRecord.softDelete(now: Long): ItemRecord =
    copy(deletedAt = now, updatedAt = now)

fun ItemRecord.undelete(now: Long): ItemRecord =
    copy(deletedAt = null, updatedAt = now)

/** رکورد جدید و مستقل بر اساس اطلاعات این رکورد. */
fun ItemRecord.asDuplicate(now: Long): ItemRecord =
    copy(
        id = 0, status = STATUS_ACTIVE, createdAt = now, updatedAt = now,
        completedAt = null, deletedAt = null
    )

/** اگر وضعیت از فرم عوض شده باشد، تاریخ اتمام را هم‌سو می‌کند. */
fun ItemRecord.withCompletionNormalized(now: Long): ItemRecord = when {
    status == STATUS_DONE && completedAt == null -> copy(completedAt = now)
    status != STATUS_DONE && completedAt != null -> copy(completedAt = null)
    else -> this
}

fun ItemRecord.hasContent(): Boolean = listOf(
    contactName, contactPhone, productCode, productName, quantity, unit, planningSite, notes
).any { it.isNotBlank() }

/** عنوان کوتاه برای نمایش در لیست. */
fun ItemRecord.displayTitle(): String = when {
    productName.isNotBlank() -> productName.trim()
    productCode.isNotBlank() -> "کد ${productCode.trim()}"
    notes.isNotBlank() -> notes.trim().lineSequence().first().take(60)
    else -> "(بدون عنوان)"
}
