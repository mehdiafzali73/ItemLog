@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog.ui

import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.stringResource
import com.personal.itemlog.R
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personal.itemlog.data.AppSettings
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.Repository
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.TextNorm
import com.personal.itemlog.domain.displayTitle
import com.personal.itemlog.export.ShareUtil

@Composable
fun SettingsScreen(vm: MainViewModel, onOpenTrash: () -> Unit, onOpenTemplates: () -> Unit) {
    val theme by vm.settings.theme.collectAsStateWithLifecycle()
    val dynamicColor by vm.settings.dynamicColor.collectAsStateWithLifecycle()
    val templates by vm.settings.templates.collectAsStateWithLifecycle()
    val trash by vm.trash.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }

    val createBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) vm.backupTo(uri)
    }
    val openBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestore = uri
    }

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("تنظیمات") }) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("پوسته", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    listOf(
                        AppSettings.THEME_SYSTEM to "مطابق سیستم",
                        AppSettings.THEME_LIGHT to "روشن",
                        AppSettings.THEME_DARK to "تیره"
                    ).forEach { (value, label) ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.settings.setTheme(value) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = theme == value, onClick = { vm.settings.setTheme(value) })
                            Text(label)
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("رنگ‌های پویا (Material You)")
                                Text(
                                    "رنگ برنامه از تصویر زمینه‌ی گوشی گرفته می‌شود",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = dynamicColor, onCheckedChange = { vm.settings.setDynamicColor(it) })
                        }
                    }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("پشتیبان‌گیری و بازیابی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "پشتیبان شامل همه‌ی رکوردها، وضعیت‌ها، تاریخ‌ها، تنظیمات و پیوست‌هاست و بدون اینترنت کار می‌کند. " +
                            "فایل پشتیبان را جایی خارج از گوشی هم نگه دارید.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        enabled = !busy, modifier = Modifier.fillMaxWidth(),
                        onClick = { createBackup.launch(Repository.backupFileName(System.currentTimeMillis())) }
                    ) { Text("ذخیره‌ی پشتیبان در حافظه") }
                    OutlinedButton(
                        enabled = !busy, modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            vm.createShareableBackup { ShareUtil.shareFile(context, it, "application/zip") }
                        }
                    ) { Text("ارسال پشتیبان با پیام‌رسان یا ایمیل") }
                    OutlinedButton(
                        enabled = !busy, modifier = Modifier.fillMaxWidth(),
                        onClick = { openBackup.launch(arrayOf("*/*")) }
                    ) { Text("بازیابی از فایل پشتیبان") }
                }
            }

            Card(Modifier.fillMaxWidth().clickable(onClick = onOpenTemplates)) {
                Column(Modifier.padding(12.dp)) {
                    Text("قالب‌های پیامک", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        TextNorm.toPersianDigits(templates.size.toString()) + " قالب · متن و شیوه‌ی نمایش آیتم‌ها قابل تنظیم است",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Card(Modifier.fillMaxWidth().clickable(onClick = onOpenTrash)) {
                Column(Modifier.padding(12.dp)) {
                    Text("حذف‌شده‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        if (trash.isEmpty()) "سطل خالی است" else TextNorm.toPersianDigits(trash.size.toString()) + " رکورد قابل بازگردانی",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("درباره‌ی برنامه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        stringResource(R.string.app_name),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "طراح و توسعه‌دهنده: مهدی افضلی",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "این برنامه شخصی و آفلاین است؛ همه‌ی اطلاعات فقط روی همین گوشی ذخیره می‌شود و هیچ اطلاعاتی بدون اجازه‌ی شما ارسال نمی‌شود.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("بازیابی از پشتیبان") },
            text = {
                Text(
                    "همه‌ی داده‌های فعلی با محتوای این فایل جایگزین می‌شوند. " +
                        "قبل از آن یک پشتیبان خودکار از وضعیت فعلی گرفته می‌شود. ادامه می‌دهید؟"
                )
            },
            confirmButton = {
                TextButton(onClick = { pendingRestore = null; vm.restoreFrom(uri) }) { Text("بازیابی") }
            },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("انصراف") } }
        )
    }
}

@Composable
fun TrashScreen(vm: MainViewModel, onBack: () -> Unit) {
    val trash by vm.trash.collectAsStateWithLifecycle()
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmPurge by remember { mutableStateOf<ItemRecord?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("حذف‌شده‌ها") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت") }
                },
                actions = {
                    if (trash.isNotEmpty()) TextButton(onClick = { confirmEmpty = true }) { Text("خالی کردن") }
                }
            )
        }
    ) { padding ->
        if (trash.isEmpty()) {
            Text(
                "سطل حذف‌شده‌ها خالی است.",
                modifier = Modifier.padding(padding).padding(24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(
                Modifier.padding(padding).fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(trash, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(r.displayTitle(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            val who = listOf(r.contactName.trim(), r.contactPhone.trim()).filter { it.isNotEmpty() }.joinToString(" — ")
                            if (who.isNotEmpty()) Text(who, style = MaterialTheme.typography.bodySmall)
                            r.deletedAt?.let {
                                Text(
                                    "حذف در " + Jalali.formatDateTime(it),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { vm.restore(r.id) }) { Text("بازگردانی") }
                                TextButton(onClick = { confirmPurge = r }) {
                                    Text("حذف همیشگی", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("خالی کردن سطل؟") },
            text = { Text("همه‌ی رکوردهای حذف‌شده و پیوست‌هایشان برای همیشه پاک می‌شوند.") },
            confirmButton = { TextButton(onClick = { confirmEmpty = false; vm.emptyTrash() }) { Text("خالی کن") } },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("انصراف") } }
        )
    }
    confirmPurge?.let { record ->
        AlertDialog(
            onDismissRequest = { confirmPurge = null },
            title = { Text("حذف همیشگی؟") },
            text = { Text("این رکورد و پیوست‌هایش دیگر قابل بازگردانی نخواهد بود.") },
            confirmButton = { TextButton(onClick = { confirmPurge = null; vm.purge(record.id) }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { confirmPurge = null }) { Text("انصراف") } }
        )
    }
}
