package com.personal.itemlog.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.personal.itemlog.domain.Jalali
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** ذخیره‌ی فایل‌های پیوست داخل حافظه‌ی خصوصی برنامه. */
class FileStore(private val context: Context) {
    val dir: File
        get() = File(context.filesDir, "attachments").also { it.mkdirs() }

    /** نام ذخیره‌شده هرگز شامل مسیر نیست. */
    fun file(storedName: String): File = File(dir, File(storedName).name)

    fun delete(storedName: String) {
        file(storedName).delete()
    }

    fun uriFor(file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    /** فایل انتخاب‌شده توسط کاربر را در حافظه‌ی برنامه کپی می‌کند. */
    fun importFromUri(uri: Uri, now: Long = System.currentTimeMillis()): Attachment? {
        val resolver = context.contentResolver
        var name: String? = null
        try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val index = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0 && !c.isNull(index)) name = c.getString(index)
                }
            }
        } catch (e: Exception) {
            // نام نامشخص؛ از نام پیش‌فرض استفاده می‌شود
        }
        val display = (name ?: uri.lastPathSegment ?: "file").ifBlank { "file" }
        val ext = extensionOf(display)
        val mime = resolver.getType(uri)
            ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase())
            ?: "application/octet-stream"
        val target = file("${UUID.randomUUID()}.$ext")
        return try {
            val input = resolver.openInputStream(uri) ?: return null
            input.use { source -> target.outputStream().use { sink -> source.copyTo(sink) } }
            Attachment(
                displayName = display,
                mimeType = mime,
                storedName = target.name,
                sizeBytes = target.length(),
                createdAt = now
            )
        } catch (e: Exception) {
            target.delete()
            null
        }
    }

    /** فایل خالی برای ذخیره‌ی خروجی دوربین. */
    fun newCameraFile(now: Long = System.currentTimeMillis()): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(now))
        return file("IMG_${stamp}_${UUID.randomUUID().toString().take(6)}.jpg")
    }

    fun cameraAttachment(file: File, now: Long = System.currentTimeMillis()): Attachment =
        Attachment(
            displayName = "عکس ${Jalali.formatDate(now)} ${Jalali.formatTime(now)}",
            mimeType = "image/jpeg",
            storedName = file.name,
            sizeBytes = file.length(),
            createdAt = now
        )

    /** همه‌ی فایل‌های فعلی را با فایل‌های پوشه‌ی مبدأ جایگزین می‌کند (برای Restore). */
    fun replaceAllWith(sourceDir: File) {
        dir.listFiles()?.forEach { it.delete() }
        sourceDir.listFiles()?.forEach { f -> f.copyTo(File(dir, f.name), overwrite = true) }
    }

    companion object {
        fun extensionOf(fileName: String): String =
            fileName.substringAfterLast('.', "")
                .filter { it.code < 128 && it.isLetterOrDigit() }
                .take(8)
                .ifEmpty { "bin" }
    }
}
