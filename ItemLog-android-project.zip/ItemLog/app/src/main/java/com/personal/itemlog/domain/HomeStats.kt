package com.personal.itemlog.domain

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_ACTIVE
import java.time.LocalDate
import java.time.ZoneId

data class HomeStats(
    val activeCount: Int,
    val todayCount: Int,
    /** رکوردهای فعالی که مربوط به روزهای قبل هستند و هنوز اتمام نشده‌اند. */
    val followUp: List<ItemRecord>
)

fun computeStats(records: List<ItemRecord>, today: LocalDate, zone: ZoneId = ZoneId.systemDefault()): HomeStats {
    val live = records.filter { it.deletedAt == null }
    val startOfToday = Jalali.startOfDay(today, zone)
    val active = live.filter { it.status == STATUS_ACTIVE }
    return HomeStats(
        activeCount = active.size,
        todayCount = live.count { it.createdAt >= startOfToday },
        followUp = active.filter { it.createdAt < startOfToday }.sortedBy { it.createdAt }
    )
}
