package com.personal.itemlog.data

import com.personal.itemlog.domain.SmsTemplate
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

object TemplateCodec {
    fun encode(templates: List<SmsTemplate>): String {
        val arr = JSONArray()
        for (t in templates) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("name", t.name)
            o.put("header", t.header)
            o.put("footer", t.footer)
            arr.put(o)
        }
        return arr.toString()
    }

    /** در صورت نامعتبر بودن، null برمی‌گرداند. */
    fun decode(json: String?): List<SmsTemplate>? {
        if (json.isNullOrBlank()) return null
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<SmsTemplate>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id", "")
                val name = o.optString("name", "")
                if (id.isBlank() || name.isBlank()) continue
                list += SmsTemplate(id, name, o.optString("header", ""), o.optString("footer", ""))
            }
            list.distinctBy { it.id }
        } catch (e: JSONException) {
            null
        }
    }
}
