package com.personal.itemlog.domain

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.data.STATUS_ACTIVE
import com.personal.itemlog.data.STATUS_DONE
import java.time.LocalDate
import java.time.ZoneId

enum class StatusFilter { ALL, ACTIVE, DONE }

enum class DatePreset(val label: String) {
    TODAY("امروز"),
    YESTERDAY("دیروز"),
    WEEK("این هفته"),
    MONTH("این ماه"),
    ALL("همه"),
    CUSTOM("بازه دلخواه")
}

data class RecordQuery(
    val text: String = "",
    val status: StatusFilter = StatusFilter.ALL,
    val fromMillis: Long? = null,
    val toMillisExclusive: Long? = null,
    val contactId: String? = null,
    val site: String = "",
    val productCode: String = "",
    val productName: String = ""
)

/** شناسه یکتای مخاطب برای گروه‌بندی و فیلتر؛ برای رکورد بدون مخاطب null است. */
fun ItemRecord.contactIdentity(): String? = when {
    contactKey.isNotBlank() -> contactKey
    contactName.isNotBlank() || contactPhone.isNotBlank() -> "$contactName|$contactPhone"
    else -> null
}

private fun ItemRecord.searchText(): String =
    TextNorm.normalize(
        listOf(productCode, productName, quantity, unit, planningSite, notes, contactName, contactPhone)
            .joinToString(" ")
    ) + " " + TextNorm.digitsOnly(contactPhone)

/** رکوردهای حذف‌شده هرگز در نتیجه نمی‌آیند. */
fun List<ItemRecord>.applyQuery(q: RecordQuery): List<ItemRecord> {
    val tokens = TextNorm.tokens(q.text)
    val site = TextNorm.normalize(q.site)
    val code = TextNorm.normalize(q.productCode)
    val name = TextNorm.normalize(q.productName)
    val from = q.fromMillis
    val to = q.toMillisExclusive
    return filter { r ->
        if (r.deletedAt != null) return@filter false
        val statusOk = when (q.status) {
            StatusFilter.ALL -> true
            StatusFilter.ACTIVE -> r.status == STATUS_ACTIVE
            StatusFilter.DONE -> r.status == STATUS_DONE
        }
        if (!statusOk) return@filter false
        if (from != null && r.createdAt < from) return@filter false
        if (to != null && r.createdAt >= to) return@filter false
        if (q.contactId != null && r.contactIdentity() != q.contactId) return@filter false
        if (site.isNotEmpty() && !TextNorm.normalize(r.planningSite).contains(site)) return@filter false
        if (code.isNotEmpty() && !TextNorm.normalize(r.productCode).contains(code)) return@filter false
        if (name.isNotEmpty() && !TextNorm.normalize(r.productName).contains(name)) return@filter false
        if (tokens.isNotEmpty()) {
            val hay = r.searchText()
            if (!tokens.all { hay.contains(it) }) return@filter false
        }
        true
    }
}

data class RecordGroup(
    val contactKey: String,
    val contactName: String,
    val contactPhone: String,
    val date: LocalDate,
    val records: List<ItemRecord>
)

enum class GroupOrder { RECENT_FIRST, BY_CONTACT }

/** رکوردهای هر مخاطب در هر روز را کنار هم گروه‌بندی می‌کند. */
fun groupRecords(
    records: List<ItemRecord>,
    order: GroupOrder,
    zone: ZoneId = ZoneId.systemDefault()
): List<RecordGroup> {
    val sorted = records.sortedByDescending { it.createdAt }
    val map = LinkedHashMap<Pair<String, LocalDate>, MutableList<ItemRecord>>()
    for (r in sorted) {
        val key = (r.contactIdentity() ?: "") to Jalali.dateOf(r.createdAt, zone)
        map.getOrPut(key) { mutableListOf() }.add(r)
    }
    val groups = map.map { (key, list) ->
        val first = list.first()
        RecordGroup(key.first, first.contactName, first.contactPhone, key.second, list)
    }
    return when (order) {
        GroupOrder.RECENT_FIRST -> groups
        GroupOrder.BY_CONTACT -> groups
            .sortedWith(compareBy<RecordGroup> { it.contactName.lowercase() }.thenBy { it.date })
            .map { g -> g.copy(records = g.records.sortedBy { it.createdAt }) }
    }
}

object DateRanges {
    /** شنبه اولین روز هفته است. */
    fun weekStart(today: LocalDate): LocalDate {
        val daysSinceSaturday = (today.dayOfWeek.value + 1) % 7
        return today.minusDays(daysSinceSaturday.toLong())
    }

    /** بازه (شامل ابتدا و انتها) به‌صورت تاریخ میلادی؛ null یعنی بدون محدودیت. */
    fun datesFor(
        preset: DatePreset,
        customFrom: LocalDate?,
        customTo: LocalDate?,
        today: LocalDate
    ): Pair<LocalDate?, LocalDate?> = when (preset) {
        DatePreset.TODAY -> today to today
        DatePreset.YESTERDAY -> today.minusDays(1) to today.minusDays(1)
        DatePreset.WEEK -> weekStart(today) to today
        DatePreset.MONTH -> {
            val j = Jalali.toJalali(today)
            Jalali.toGregorian(j.year, j.month, 1) to today
        }
        DatePreset.ALL -> null to null
        DatePreset.CUSTOM -> customFrom to customTo
    }

    fun toMillis(
        fromDate: LocalDate?,
        toDate: LocalDate?,
        zone: ZoneId = ZoneId.systemDefault()
    ): Pair<Long?, Long?> {
        val start = fromDate?.let { Jalali.startOfDay(it, zone) }
        val endExclusive = toDate?.let { Jalali.startOfDay(it.plusDays(1), zone) }
        return Pair(start, endExclusive)
    }
}

data class ReportFilter(
    val preset: DatePreset = DatePreset.TODAY,
    val customFrom: LocalDate? = null,
    val customTo: LocalDate? = null,
    val contactId: String? = null,
    val contactLabel: String = "",
    val status: StatusFilter = StatusFilter.ALL,
    val site: String = "",
    val code: String = "",
    val name: String = ""
) {
    fun toQuery(today: LocalDate, zone: ZoneId = ZoneId.systemDefault()): RecordQuery {
        val (from, to) = DateRanges.datesFor(preset, customFrom, customTo, today)
        val (fromMs, toMs) = DateRanges.toMillis(from, to, zone)
        return RecordQuery(
            status = status,
            fromMillis = fromMs,
            toMillisExclusive = toMs,
            contactId = contactId,
            site = site,
            productCode = code,
            productName = name
        )
    }

    fun dateLabel(today: LocalDate): String {
        val (from, to) = DateRanges.datesFor(preset, customFrom, customTo, today)
        return when {
            from == null && to == null -> "همه تاریخ‌ها"
            from != null && to != null && from == to -> Jalali.formatDate(from)
            from != null && to != null -> "از ${Jalali.formatDate(from)} تا ${Jalali.formatDate(to)}"
            from != null -> "از ${Jalali.formatDate(from!!)}"
            else -> "تا ${Jalali.formatDate(to!!)}"
        }
    }

    /** خلاصه‌ی فیلترها برای زیرعنوان گزارش. */
    fun describe(today: LocalDate): String {
        val parts = mutableListOf(dateLabel(today))
        if (contactId != null && contactLabel.isNotBlank()) parts += "مخاطب: $contactLabel"
        when (status) {
            StatusFilter.ACTIVE -> parts += "وضعیت: فعال"
            StatusFilter.DONE -> parts += "وضعیت: اتمام"
            StatusFilter.ALL -> Unit
        }
        if (site.isNotBlank()) parts += "سایت: ${site.trim()}"
        if (code.isNotBlank()) parts += "کد کالا: ${code.trim()}"
        if (name.isNotBlank()) parts += "نام کالا: ${name.trim()}"
        return parts.joinToString(" | ")
    }
}
