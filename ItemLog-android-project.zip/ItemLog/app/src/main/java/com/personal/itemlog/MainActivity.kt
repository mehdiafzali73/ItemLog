@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.personal.itemlog.ui.FormScreen
import com.personal.itemlog.ui.HomeScreen
import com.personal.itemlog.ui.ItemLogTheme
import com.personal.itemlog.ui.MainViewModel
import com.personal.itemlog.ui.ReportsScreen
import com.personal.itemlog.ui.SettingsScreen
import com.personal.itemlog.ui.TemplatesScreen
import com.personal.itemlog.ui.TrashScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: MainViewModel = viewModel()
            val theme by vm.settings.theme.collectAsStateWithLifecycle()
            val dynamicColor by vm.settings.dynamicColor.collectAsStateWithLifecycle()
            ItemLogTheme(theme, dynamicColor) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot(vm)
                }
            }
        }
    }
}

private data class TopLevel(val route: String, val label: String, val icon: ImageVector)

private val topLevelDestinations = listOf(
    TopLevel("home", "خانه", Icons.Default.Home),
    TopLevel("reports", "گزارش‌ها", Icons.Default.DateRange),
    TopLevel("settings", "تنظیمات", Icons.Default.Settings)
)

@Composable
fun AppRoot(vm: MainViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.messages.collect { message ->
            val result = snackbar.showSnackbar(
                message = message.text,
                actionLabel = message.actionLabel,
                duration = if (message.actionLabel != null) SnackbarDuration.Long else SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) message.onAction?.invoke()
        }
    }

    val showBottomBar = topLevelDestinations.any { it.route == route }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    topLevelDestinations.forEach { dest ->
                        NavigationBarItem(
                            selected = route == dest.route,
                            onClick = {
                                nav.navigate(dest.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = null) },
                            label = { Text(dest.label) }
                        )
                    }
                }
            }
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") {
                HomeScreen(
                    vm = vm,
                    onNew = { nav.navigate("form/0/0/0") },
                    onEdit = { id -> nav.navigate("form/$id/0/0") },
                    onDuplicate = { id -> nav.navigate("form/0/$id/0") },
                    onAddForContact = { id -> nav.navigate("form/0/0/$id") }
                )
            }
            composable("reports") { ReportsScreen(vm) }
            composable("settings") {
                SettingsScreen(
                    vm,
                    onOpenTrash = { nav.navigate("trash") },
                    onOpenTemplates = { nav.navigate("templates") }
                )
            }
            composable("trash") { TrashScreen(vm, onBack = { nav.popBackStack() }) }
            composable("templates") { TemplatesScreen(vm, onBack = { nav.popBackStack() }) }
            composable(
                "form/{id}/{dup}/{contact}",
                arguments = listOf(
                    navArgument("id") { type = NavType.LongType },
                    navArgument("dup") { type = NavType.LongType },
                    navArgument("contact") { type = NavType.LongType }
                )
            ) { entry ->
                FormScreen(
                    recordId = entry.arguments?.getLong("id") ?: 0L,
                    duplicateFrom = entry.arguments?.getLong("dup") ?: 0L,
                    contactFrom = entry.arguments?.getLong("contact") ?: 0L,
                    vm = vm,
                    onClose = { nav.popBackStack() }
                )
            }
        }
    }
}
