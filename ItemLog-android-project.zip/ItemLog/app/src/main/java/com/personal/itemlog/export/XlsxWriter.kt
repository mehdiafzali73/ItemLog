package com.personal.itemlog.export

import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * نویسنده‌ی سبک فایل Excel (xlsx) بدون کتابخانه‌ی خارجی.
 * شیت راست‌به‌چپ است؛ مقادیر عددی (Number) به‌صورت عدد و بقیه به‌صورت متن ذخیره می‌شوند.
 */
object XlsxWriter {
    fun write(out: OutputStream, sheetName: String, headers: List<String>, rows: List<List<Any?>>) {
        ZipOutputStream(out).use { zip ->
            fun put(name: String, content: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            put("[Content_Types].xml", CONTENT_TYPES)
            put("_rels/.rels", ROOT_RELS)
            put("xl/workbook.xml", workbookXml(sheetName))
            put("xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
            put("xl/styles.xml", STYLES)
            put("xl/worksheets/sheet1.xml", sheetXml(headers, rows))
        }
    }

    private fun sheetXml(headers: List<String>, rows: List<List<Any?>>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        sb.append("""<sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>""")
        sb.append("<cols>")
        for (c in headers.indices) {
            var longest = headers[c].length
            for (row in rows) {
                val v = row.getOrNull(c)?.toString().orEmpty()
                val firstLine = v.lineSequence().maxOfOrNull { it.length } ?: 0
                if (firstLine > longest) longest = firstLine
            }
            val width = (longest + 3).coerceIn(9, 50)
            sb.append("""<col min="${c + 1}" max="${c + 1}" width="$width" customWidth="1"/>""")
        }
        sb.append("</cols>")
        sb.append("<sheetData>")
        sb.append("""<row r="1">""")
        headers.forEachIndexed { c, h -> appendCell(sb, c, 1, h, header = true) }
        sb.append("</row>")
        rows.forEachIndexed { i, row ->
            val r = i + 2
            sb.append("""<row r="$r">""")
            row.forEachIndexed { c, v -> appendCell(sb, c, r, v, header = false) }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    private fun appendCell(sb: StringBuilder, col: Int, row: Int, value: Any?, header: Boolean) {
        val ref = columnName(col) + row
        val style = if (header) """ s="1"""" else ""
        when {
            value == null -> Unit
            value is Number -> sb.append("""<c r="$ref"$style><v>$value</v></c>""")
            else -> {
                val text = value.toString()
                if (text.isEmpty()) return
                sb.append("""<c r="$ref"$style t="inlineStr"><is><t xml:space="preserve">${escape(text)}</t></is></c>""")
            }
        }
    }

    fun columnName(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n >= 0) {
            sb.insert(0, 'A' + (n % 26))
            n = n / 26 - 1
        }
        return sb.toString()
    }

    private fun escape(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch.code < 0x20 && ch != '\n' && ch != '\r' && ch != '\t' -> Unit
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun workbookXml(sheetName: String): String {
        val safe = sheetName.filter { it !in "[]:*?/\\" }.take(31).ifEmpty { "Sheet1" }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""" +
            """<bookViews><workbookView/></bookViews>""" +
            """<sheets><sheet name="${escape(safe)}" sheetId="1" r:id="rId1"/></sheets></workbook>"""
    }

    private const val CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>"""

    private const val ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""

    private const val WORKBOOK_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""

    private const val STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""
}
