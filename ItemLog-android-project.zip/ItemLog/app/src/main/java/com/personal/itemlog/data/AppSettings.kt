package com.personal.itemlog.data

import android.content.Context
import com.personal.itemlog.domain.DefaultTemplates
import com.personal.itemlog.domain.SmsItemStyle
import com.personal.itemlog.domain.SmsTemplate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(prefs.getString(KEY_THEME, THEME_SYSTEM) ?: THEME_SYSTEM)

    /** system | light | dark */
    val theme: StateFlow<String> = _theme

    private val _dynamicColor = MutableStateFlow(prefs.getBoolean(KEY_DYNAMIC, false))
    val dynamicColor: StateFlow<Boolean> = _dynamicColor

    private val _templates = MutableStateFlow(loadTemplates())
    val templates: StateFlow<List<SmsTemplate>> = _templates

    private val _defaultTemplateId =
        MutableStateFlow(prefs.getString(KEY_SMS_DEFAULT, DefaultTemplates.DEFAULT_ID) ?: DefaultTemplates.DEFAULT_ID)
    val defaultTemplateId: StateFlow<String> = _defaultTemplateId

    private val _itemStyle = MutableStateFlow(SmsItemStyle.fromKey(prefs.getString(KEY_SMS_STYLE, null)))
    val itemStyle: StateFlow<SmsItemStyle> = _itemStyle

    private fun loadTemplates(): List<SmsTemplate> =
        TemplateCodec.decode(prefs.getString(KEY_SMS_TEMPLATES, null))?.takeIf { it.isNotEmpty() }
            ?: DefaultTemplates.create()

    fun setTheme(value: String) {
        if (value !in THEMES) return
        prefs.edit().putString(KEY_THEME, value).apply()
        _theme.value = value
    }

    fun setDynamicColor(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DYNAMIC, enabled).apply()
        _dynamicColor.value = enabled
    }

    // ---------- قالب‌های پیامک ----------

    private fun saveTemplates(list: List<SmsTemplate>) {
        prefs.edit().putString(KEY_SMS_TEMPLATES, TemplateCodec.encode(list)).apply()
        _templates.value = list
    }

    /** قالب پیش‌فرض؛ اگر شناسه‌اش پاک شده باشد، اولین قالب. */
    fun defaultTemplate(): SmsTemplate {
        val list = _templates.value
        return list.firstOrNull { it.id == _defaultTemplateId.value } ?: list.first()
    }

    fun templateById(id: String?): SmsTemplate =
        _templates.value.firstOrNull { it.id == id } ?: defaultTemplate()

    fun upsertTemplate(template: SmsTemplate) {
        val list = _templates.value
        val updated = if (list.any { it.id == template.id }) {
            list.map { if (it.id == template.id) template else it }
        } else {
            list + template
        }
        saveTemplates(updated)
    }

    /** همیشه حداقل یک قالب باقی می‌ماند. */
    fun deleteTemplate(id: String) {
        val list = _templates.value
        if (list.size <= 1) return
        val updated = list.filter { it.id != id }
        saveTemplates(updated)
        if (_defaultTemplateId.value == id) setDefaultTemplate(updated.first().id)
    }

    fun setDefaultTemplate(id: String) {
        prefs.edit().putString(KEY_SMS_DEFAULT, id).apply()
        _defaultTemplateId.value = id
    }

    fun setItemStyle(style: SmsItemStyle) {
        prefs.edit().putString(KEY_SMS_STYLE, style.key).apply()
        _itemStyle.value = style
    }

    fun resetTemplates() {
        saveTemplates(DefaultTemplates.create())
        setDefaultTemplate(DefaultTemplates.DEFAULT_ID)
    }

    // ---------- پشتیبان‌گیری ----------

    fun export(): Map<String, String> = mapOf(
        KEY_THEME to _theme.value,
        KEY_DYNAMIC to _dynamicColor.value.toString(),
        KEY_SMS_TEMPLATES to TemplateCodec.encode(_templates.value),
        KEY_SMS_DEFAULT to _defaultTemplateId.value,
        KEY_SMS_STYLE to _itemStyle.value.key
    )

    fun import(values: Map<String, String>) {
        values[KEY_THEME]?.let { setTheme(it) }
        values[KEY_DYNAMIC]?.let { setDynamicColor(it == "true") }
        TemplateCodec.decode(values[KEY_SMS_TEMPLATES])?.takeIf { it.isNotEmpty() }?.let { saveTemplates(it) }
        values[KEY_SMS_DEFAULT]?.let { id ->
            if (_templates.value.any { it.id == id }) setDefaultTemplate(id)
        }
        values[KEY_SMS_STYLE]?.let { setItemStyle(SmsItemStyle.fromKey(it)) }
    }

    companion object {
        const val KEY_THEME = "theme"
        const val KEY_DYNAMIC = "dynamicColor"
        const val KEY_SMS_TEMPLATES = "smsTemplates"
        const val KEY_SMS_DEFAULT = "smsDefaultTemplate"
        const val KEY_SMS_STYLE = "smsItemStyle"
        const val THEME_SYSTEM = "system"
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        val THEMES = setOf(THEME_SYSTEM, THEME_LIGHT, THEME_DARK)
    }
}
