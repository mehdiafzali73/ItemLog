package com.personal.itemlog.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _theme = MutableStateFlow(prefs.getString(KEY_THEME, THEME_SYSTEM) ?: THEME_SYSTEM)

    /** system | light | dark */
    val theme: StateFlow<String> = _theme

    fun setTheme(value: String) {
        if (value !in THEMES) return
        prefs.edit().putString(KEY_THEME, value).apply()
        _theme.value = value
    }

    fun export(): Map<String, String> = mapOf(KEY_THEME to _theme.value)

    fun import(values: Map<String, String>) {
        values[KEY_THEME]?.let { setTheme(it) }
    }

    companion object {
        const val KEY_THEME = "theme"
        const val THEME_SYSTEM = "system"
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        val THEMES = setOf(THEME_SYSTEM, THEME_LIGHT, THEME_DARK)
    }
}
