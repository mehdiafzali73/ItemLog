@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personal.itemlog.domain.DatePreset
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.ReportText
import com.personal.itemlog.domain.StatusDisplay
import com.personal.itemlog.domain.TextNorm
import com.personal.itemlog.domain.contactIdentity
import com.personal.itemlog.export.ShareUtil
import java.time.LocalDate

@Composable
fun ReportsScreen(vm: MainViewModel) {
    val filter by vm.reportFilter.collectAsStateWithLifecycle()
    val records by vm.reportRecords.collectAsStateWithLifecycle()
    val groups by vm.reportGroups.collectAsStateWithLifecycle()
    val contacts by vm.contactOptions.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val today = LocalDate.now()
    var showMore by rememberSaveable { mutableStateOf(false) }
    var contactMenu by remember { mutableStateOf(false) }
    // ۰ = هیچ، ۱ = از تاریخ، ۲ = تا تاریخ
    var picking by remember { mutableIntStateOf(0) }
    val templates by vm.settings.templates.collectAsStateWithLifecycle()
    val defaultTemplateId by vm.settings.defaultTemplateId.collectAsStateWithLifecycle()
    var chosenTemplateId by remember { mutableStateOf<String?>(null) }
    var templateMenu by remember { mutableStateOf(false) }
    val activeTemplate = templates.firstOrNull { it.id == chosenTemplateId }
        ?: templates.firstOrNull { it.id == defaultTemplateId }
        ?: templates.first()

    fun reportText(): String =
        ReportText.build(groups, "گزارش کالاها\n" + filter.describe(today), StatusDisplay.ALWAYS)

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("گزارش‌ها") }) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "filters") {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("بازه‌ی زمانی", style = MaterialTheme.typography.labelLarge)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(DatePreset.entries.toList()) { preset ->
                                FilterChip(
                                    selected = filter.preset == preset,
                                    onClick = {
                                        vm.updateReportFilter {
                                            if (preset == DatePreset.CUSTOM) {
                                                it.copy(
                                                    preset = preset,
                                                    customFrom = it.customFrom ?: today,
                                                    customTo = it.customTo ?: today
                                                )
                                            } else {
                                                it.copy(preset = preset)
                                            }
                                        }
                                    },
                                    label = { Text(preset.label) }
                                )
                            }
                        }
                        if (filter.preset == DatePreset.CUSTOM) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { picking = 1 }, modifier = Modifier.weight(1f)) {
                                    Text("از: " + (filter.customFrom?.let { Jalali.formatNumeric(it) } ?: "—"))
                                }
                                OutlinedButton(onClick = { picking = 2 }, modifier = Modifier.weight(1f)) {
                                    Text("تا: " + (filter.customTo?.let { Jalali.formatNumeric(it) } ?: "—"))
                                }
                            }
                        }

                        Text("مخاطب", style = MaterialTheme.typography.labelLarge)
                        Box {
                            OutlinedButton(onClick = { contactMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    if (filter.contactId == null) "همه‌ی مخاطبین" else filter.contactLabel,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                            DropdownMenu(expanded = contactMenu, onDismissRequest = { contactMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("همه‌ی مخاطبین") },
                                    onClick = {
                                        contactMenu = false
                                        vm.updateReportFilter { it.copy(contactId = null, contactLabel = "") }
                                    }
                                )
                                contacts.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.label) },
                                        onClick = {
                                            contactMenu = false
                                            vm.updateReportFilter { it.copy(contactId = option.id, contactLabel = option.label) }
                                        }
                                    )
                                }
                            }
                        }

                        Text("وضعیت", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatusFilterChips(filter.status) { s -> vm.updateReportFilter { it.copy(status = s) } }
                        }

                        TextButton(onClick = { showMore = !showMore }) {
                            Text(if (showMore) "بستن فیلترهای بیشتر" else "فیلترهای بیشتر (سایت، کد، نام کالا)")
                        }
                        if (showMore) {
                            OutlinedTextField(
                                value = filter.site, onValueChange = { v -> vm.updateReportFilter { it.copy(site = v) } },
                                label = { Text("سایت برنامه‌ریزی") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = filter.code, onValueChange = { v -> vm.updateReportFilter { it.copy(code = v) } },
                                    label = { Text("کد کالا") }, singleLine = true, modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = filter.name, onValueChange = { v -> vm.updateReportFilter { it.copy(name = v) } },
                                    label = { Text("نام کالا") }, singleLine = true, modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            item(key = "actions") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(
                        TextNorm.toPersianDigits(records.size.toString()) + " رکورد در " +
                            TextNorm.toPersianDigits(groups.size.toString()) + " گروه  •  " + filter.dateLabel(today),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val enabled = records.isNotEmpty() && !busy
                    Box {
                        OutlinedButton(onClick = { templateMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("قالب پیامک: " + activeTemplate.name, modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = templateMenu, onDismissRequest = { templateMenu = false }) {
                            templates.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text(t.name) },
                                    onClick = { chosenTemplateId = t.id; templateMenu = false }
                                )
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            enabled = enabled, modifier = Modifier.weight(1f),
                            onClick = { ShareUtil.shareText(context, reportText(), "گزارش کالاها") }
                        ) { Text("اشتراک متن") }
                        FilledTonalButton(
                            enabled = enabled, modifier = Modifier.weight(1f),
                            onClick = {
                                val ids = groups.map { it.contactKey }.distinct()
                                val phone = groups.firstOrNull { it.contactPhone.isNotBlank() }?.contactPhone
                                if (ids.size == 1 && !phone.isNullOrBlank()) {
                                    val name = groups.firstOrNull { it.contactName.isNotBlank() }?.contactName.orEmpty()
                                    ShareUtil.composeSms(
                                        context, phone,
                                        vm.buildSms(activeTemplate.id, name, groups.flatMap { it.records })
                                    )
                                } else {
                                    Toast.makeText(
                                        context,
                                        "برای پیامک، مخاطب را انتخاب کنید (فقط یک مخاطب دارای شماره)",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        ) { Text("پیامک") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            enabled = enabled, modifier = Modifier.weight(1f),
                            onClick = { vm.exportPdf { ShareUtil.shareFile(context, it, "application/pdf") } }
                        ) { Text("خروجی PDF") }
                        FilledTonalButton(
                            enabled = enabled, modifier = Modifier.weight(1f),
                            onClick = {
                                vm.exportExcel {
                                    ShareUtil.shareFile(
                                        context, it,
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                    )
                                }
                            }
                        ) { Text("خروجی Excel") }
                    }
                }
            }

            if (groups.isEmpty()) {
                item(key = "empty") {
                    Text(
                        "برای این فیلترها رکوردی وجود ندارد.",
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            items(groups, key = { "${it.contactKey}|${it.date}" }) { g ->
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            ReportText.groupHeader(g),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        g.records.forEachIndexed { i, r ->
                            Text(ReportText.recordBlock(r, i + 1, StatusDisplay.ALWAYS), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }

    if (picking != 0) {
        val initial = (if (picking == 1) filter.customFrom else filter.customTo) ?: today
        JalaliDatePickerDialog(
            initial = initial,
            onDismiss = { picking = 0 },
            onConfirm = { date ->
                if (picking == 1) vm.updateReportFilter { it.copy(customFrom = date) }
                else vm.updateReportFilter { it.copy(customTo = date) }
                picking = 0
            }
        )
    }
}
