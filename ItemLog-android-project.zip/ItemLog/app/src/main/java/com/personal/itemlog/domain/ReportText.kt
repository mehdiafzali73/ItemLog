package com.personal.itemlog.domain

import com.personal.itemlog.data.ItemRecord

enum class StatusDisplay { NONE, ALWAYS, DONE_ONLY }

/** ساخت متن گزارش/پیامک؛ فیلدهای خالی هرگز نمایش داده نمی‌شوند. */
object ReportText {
    fun statusLabel(r: ItemRecord): String = if (r.isDone) "اتمام" else "فعال"

    fun mainLine(r: ItemRecord): String {
        val name = r.productName.trim()
        val code = r.productCode.trim().takeIf { it.isNotEmpty() }?.let { "(کد $it)" }.orEmpty()
        val main = listOf(name, code).filter { it.isNotEmpty() }.joinToString(" ")
        val qty = listOf(r.quantity.trim(), r.unit.trim()).filter { it.isNotEmpty() }.joinToString(" ")
        val line = listOf(main, qty).filter { it.isNotEmpty() }.joinToString(" — ")
        return line.ifEmpty { "—" }
    }

    fun recordBlock(r: ItemRecord, index: Int, statusDisplay: StatusDisplay): String {
        val sb = StringBuilder()
        sb.append(TextNorm.toPersianDigits(index.toString())).append(". ").append(mainLine(r))
        if (r.planningSite.isNotBlank()) sb.append("\n   سایت برنامه‌ریزی: ").append(r.planningSite.trim())
        if (r.notes.isNotBlank()) sb.append("\n   توضیحات: ").append(r.notes.trim())
        val showStatus = when (statusDisplay) {
            StatusDisplay.NONE -> false
            StatusDisplay.ALWAYS -> true
            StatusDisplay.DONE_ONLY -> r.isDone
        }
        if (showStatus) sb.append("\n   وضعیت: ").append(statusLabel(r))
        return sb.toString()
    }

    fun groupHeader(g: RecordGroup): String {
        val who = listOf(g.contactName.trim(), g.contactPhone.trim())
            .filter { it.isNotEmpty() }
            .joinToString(" — ")
            .ifEmpty { "بدون مخاطب" }
        return who + "\n" + Jalali.formatDate(g.date)
    }

    fun build(
        groups: List<RecordGroup>,
        title: String? = null,
        statusDisplay: StatusDisplay = StatusDisplay.ALWAYS
    ): String {
        val sections = mutableListOf<String>()
        if (!title.isNullOrBlank()) sections += title.trim()
        for (g in groups) {
            val body = g.records.mapIndexed { i, r -> recordBlock(r, i + 1, statusDisplay) }
            sections += groupHeader(g) + "\n" + body.joinToString("\n")
        }
        return sections.joinToString("\n\n")
    }
}
