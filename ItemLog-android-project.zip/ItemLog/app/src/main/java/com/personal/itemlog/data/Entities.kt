package com.personal.itemlog.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

const val STATUS_ACTIVE = "ACTIVE"
const val STATUS_DONE = "DONE"

/**
 * یک رکورد کالا. اطلاعات مخاطب، کالا و سایت برنامه‌ریزی مستقیماً داخل خود رکورد ذخیره می‌شوند
 * (هیچ Master Data وجود ندارد) تا تغییرات بعدی روی سوابق قبلی اثر نگذارد.
 */
@Entity(
    tableName = "records",
    indices = [Index("status"), Index("deletedAt"), Index("createdAt")]
)
data class ItemRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactKey: String = "",
    val contactName: String = "",
    val contactPhone: String = "",
    val productCode: String = "",
    val productName: String = "",
    val quantity: String = "",
    val unit: String = "",
    val planningSite: String = "",
    val notes: String = "",
    val status: String = STATUS_ACTIVE,
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    val completedAt: Long? = null,
    val deletedAt: Long? = null
)

@Entity(
    tableName = "attachments",
    foreignKeys = [
        ForeignKey(
            entity = ItemRecord::class,
            parentColumns = ["id"],
            childColumns = ["recordId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("recordId")]
)
data class Attachment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recordId: Long = 0,
    val displayName: String = "",
    val mimeType: String = "",
    val storedName: String = "",
    val sizeBytes: Long = 0,
    val createdAt: Long = 0
)
