package com.personal.itemlog.domain

object SpeechText {
    /** متن گفتاری را به انتهای متن فعلی فیلد اضافه می‌کند. */
    fun merge(existing: String, spoken: String): String {
        val s = spoken.trim()
        if (s.isEmpty()) return existing
        return if (existing.isBlank()) s else existing.trimEnd() + " " + s
    }
}
