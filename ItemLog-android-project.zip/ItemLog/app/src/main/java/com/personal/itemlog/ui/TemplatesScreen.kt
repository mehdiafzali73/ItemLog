@file:OptIn(ExperimentalMaterial3Api::class)

package com.personal.itemlog.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.domain.SmsBuilder
import com.personal.itemlog.domain.SmsItemStyle
import com.personal.itemlog.domain.SmsTemplate
import com.personal.itemlog.domain.TextNorm
import java.util.UUID

private fun sampleRecords(): List<ItemRecord> {
    val now = System.currentTimeMillis()
    return listOf(
        ItemRecord(
            productCode = "450", productName = "الکترود گرافیتی", quantity = "2", unit = "عدد",
            planningSite = "فولادسازی", notes = "فوری", createdAt = now
        ),
        ItemRecord(productName = "کابل", quantity = "10", unit = "متر", createdAt = now + 1)
    )
}

@Composable
fun TemplatesScreen(vm: MainViewModel, onBack: () -> Unit) {
    val templates by vm.settings.templates.collectAsStateWithLifecycle()
    val defaultId by vm.settings.defaultTemplateId.collectAsStateWithLifecycle()
    val style by vm.settings.itemStyle.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<SmsTemplate?>(null) }
    var confirmDelete by remember { mutableStateOf<SmsTemplate?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("قالب‌های پیامک") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت") }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editing = SmsTemplate(UUID.randomUUID().toString(), "", "سلام {نام} عزیز\n", "") },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("قالب جدید") }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "help") {
                SectionCard("نحوه‌ی ساخت پیامک") {
                    Text(
                        "متن هر قالب اول پیامک می‌آید و بعد از آن فقط آیتم‌های کالا درج می‌شود. " +
                            "متن پایانی اختیاری است. در متن می‌توانید از این متغیرها استفاده کنید: " +
                            SmsBuilder.PLACEHOLDERS.joinToString("  "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text("شیوه‌ی نمایش آیتم‌ها", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmsItemStyle.entries.forEach { st ->
                            FilterChip(
                                selected = style == st,
                                onClick = { vm.settings.setItemStyle(st) },
                                label = { Text(st.label) }
                            )
                        }
                    }
                    Text(
                        if (style == SmsItemStyle.DETAILED) "هر آیتم در چند خط با عنوان مشخص برای کد، تعداد، سایت و توضیحات."
                        else "هر آیتم در یک خط؛ مناسب پیامک کوتاه‌تر.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            items(templates, key = { it.id }) { t ->
                val isDefault = t.id == defaultId
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDefault) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceContainerHigh
                    )
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(t.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (isDefault) {
                                Text("پیش‌فرض", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (t.header.isNotBlank()) {
                            Text(t.header.trim(), style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                        Text("⋮ فهرست آیتم‌ها ⋮", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (t.footer.isNotBlank()) {
                            Text(t.footer.trim(), style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                            TextButton(onClick = { editing = t }) { Text("ویرایش") }
                            if (!isDefault) TextButton(onClick = { vm.settings.setDefaultTemplate(t.id) }) { Text("پیش‌فرض کردن") }
                            if (templates.size > 1) {
                                TextButton(onClick = { confirmDelete = t }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                            }
                        }
                    }
                }
            }

            item(key = "reset") {
                TextButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("بازگردانی قالب‌های پیش‌فرض برنامه")
                }
            }
        }
    }

    editing?.let { t ->
        TemplateEditorDialog(
            initial = t,
            style = style,
            onDismiss = { editing = null },
            onSave = { saved ->
                vm.saveTemplate(saved)
                editing = null
            }
        )
    }

    confirmDelete?.let { t ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("حذف قالب؟") },
            text = { Text("قالب «${t.name}» حذف می‌شود.") },
            confirmButton = {
                TextButton(onClick = { vm.settings.deleteTemplate(t.id); confirmDelete = null }) {
                    Text("حذف", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("انصراف") } }
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("بازگردانی قالب‌ها؟") },
            text = { Text("همه‌ی قالب‌های فعلی حذف و سه قالب پیش‌فرض برنامه جایگزین می‌شوند.") },
            confirmButton = {
                TextButton(onClick = { vm.settings.resetTemplates(); confirmReset = false }) { Text("بازگردانی") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun TemplateEditorDialog(
    initial: SmsTemplate,
    style: SmsItemStyle,
    onDismiss: () -> Unit,
    onSave: (SmsTemplate) -> Unit
) {
    var name by remember(initial.id) { mutableStateOf(initial.name) }
    var header by remember(initial.id) { mutableStateOf(initial.header) }
    var footer by remember(initial.id) { mutableStateOf(initial.footer) }

    val draft = SmsTemplate(initial.id, name.trim(), header.trimEnd(), footer.trim())
    val preview = remember(name, header, footer, style) {
        SmsBuilder.render(draft, "علی رضایی", sampleRecords(), style)
    }
    val length = preview.length
    val segments = if (length <= 70) 1 else (length + 66) / 67

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "بستن") }
                    Text(
                        if (initial.name.isBlank()) "قالب جدید" else "ویرایش قالب",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(enabled = name.isNotBlank(), onClick = { onSave(draft) }) { Text("ذخیره") }
                }
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("نام قالب") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = header, onValueChange = { header = it },
                        label = { Text("متن قبل از آیتم‌ها") }, minLines = 3, modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmsBuilder.PLACEHOLDERS.forEach { ph ->
                            SuggestionChip(onClick = { header += ph }, label = { Text(ph) })
                        }
                    }
                    OutlinedTextField(
                        value = footer, onValueChange = { footer = it },
                        label = { Text("متن بعد از آیتم‌ها (اختیاری)") }, minLines = 2, modifier = Modifier.fillMaxWidth()
                    )

                    Text("پیش‌نمایش (با نمونه‌ی فرضی)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(preview, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text(
                                "حدود " + TextNorm.toPersianDigits(length.toString()) + " کاراکتر · " +
                                    TextNorm.toPersianDigits(segments.toString()) + " پیامک",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }
        }
    }
}
