package com.personal.itemlog.export

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** اشتراک‌گذاری با Share استاندارد اندروید؛ بدون وابستگی به پیام‌رسان خاص. */
object ShareUtil {
    fun shareText(context: Context, text: String, subject: String? = null) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            if (subject != null) putExtra(Intent.EXTRA_SUBJECT, subject)
        }
        start(context, Intent.createChooser(send, "اشتراک‌گذاری"))
    }

    fun shareFile(context: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        start(context, Intent.createChooser(send, "اشتراک‌گذاری").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }

    /** برنامه‌ی پیامک را با متن آماده باز می‌کند؛ ارسال نهایی با کاربر است. */
    fun composeSms(context: Context, phone: String, body: String) {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(phone))).apply {
            putExtra("sms_body", body)
        }
        start(context, intent)
    }

    fun openFile(context: Context, uri: Uri, mime: String) {
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        start(context, view, "برنامه‌ای برای باز کردن این فایل روی گوشی پیدا نشد")
    }

    private fun start(context: Context, intent: Intent, missingMessage: String = "برنامه‌ی مناسبی پیدا نشد") {
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, missingMessage, Toast.LENGTH_LONG).show()
        }
    }
}
