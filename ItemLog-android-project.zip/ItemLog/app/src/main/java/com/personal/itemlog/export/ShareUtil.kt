package com.personal.itemlog.export

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** اشتراک‌گذاری با Share استاندارد اندروید؛ بدون وابستگی به پیام‌رسان یا شبکه‌ی اجتماعی خاص. */
object ShareUtil {
    fun shareText(context: Context, text: String, subject: String? = null) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            if (subject != null) putExtra(Intent.EXTRA_SUBJECT, subject)
        }
        start(context, Intent.createChooser(send, "اشتراک‌گذاری"))
    }

    fun shareFile(context: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        start(context, Intent.createChooser(send, "اشتراک‌گذاری").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }

    /**
     * اشتراک‌گذاری متن به همراه یک یا چند پیوست (عکس یا فایل) در شبکه‌های اجتماعی و پیام‌رسان‌ها.
     * اگر پیوستی وجود نداشته باشد، فقط متن ارسال می‌شود.
     */
    fun shareTextWithFiles(context: Context, text: String, files: List<File>, subject: String? = null) {
        if (files.isEmpty()) {
            shareText(context, text, subject)
            return
        }
        val uris = ArrayList<Uri>()
        val clip = ClipData.newRawUri("attachment", Uri.EMPTY)
        var mimePrefix: String? = null
        for ((index, f) in files.withIndex()) {
            if (!f.exists()) continue
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
            uris.add(uri)
            val mime = mimeFor(f)
            if (index == 0) {
                clip.addItem(ClipData.Item(uri))
            } else {
                clip.addItem(ClipData.Item(uri))
            }
            mimePrefix = when {
                mimePrefix == null -> mime
                mimePrefix == mime -> mime
                else -> "*/*"
            }
        }
        if (uris.isEmpty()) {
            shareText(context, text, subject)
            return
        }
        val send = Intent(if (uris.size > 1) Intent.ACTION_SEND_MULTIPLE else Intent.ACTION_SEND).apply {
            type = mimePrefix ?: "*/*"
            putExtra(Intent.EXTRA_TEXT, text)
            if (subject != null) putExtra(Intent.EXTRA_SUBJECT, subject)
            if (uris.size > 1) {
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            } else {
                putExtra(Intent.EXTRA_STREAM, uris.first())
            }
            clipData = clip
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        start(
            context,
            Intent.createChooser(send, "اشتراک‌گذاری").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }

    private fun mimeFor(file: File): String {
        val ext = file.extension.lowercase()
        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "pdf" -> "application/pdf"
            else -> "*/*"
        }
    }

    /** برنامه‌ی پیامک را با متن آماده باز می‌کند؛ ارسال نهایی با کاربر است. */
    fun composeSms(context: Context, phone: String, body: String) {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(phone))).apply {
            putExtra("sms_body", body)
        }
        start(context, intent)
    }

    fun openFile(context: Context, uri: Uri, mime: String) {
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        start(context, view, "برنامه‌ای برای باز کردن این فایل روی گوشی پیدا نشد")
    }

    private fun start(context: Context, intent: Intent, missingMessage: String = "برنامه‌ی مناسبی پیدا نشد") {
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, missingMessage, Toast.LENGTH_LONG).show()
        }
    }
}
