package com.personal.itemlog.domain

data class PickedContact(val lookupKey: String, val name: String, val phone: String) {
    val searchName: String = TextNorm.normalize(name)
    val searchDigits: String = TextNorm.digitsOnly(phone)

    /** جستجو بر اساس نام، نام خانوادگی یا شماره تلفن. */
    fun matches(query: String): Boolean {
        val q = TextNorm.normalize(query)
        if (q.isEmpty()) return true
        val tokens = q.split(' ').filter { it.isNotEmpty() }
        if (tokens.all { searchName.contains(it) }) return true
        val qDigits = TextNorm.digitsOnly(query)
        val hasLetters = q.any { it.isLetter() }
        if (hasLetters || qDigits.length < 2) return false
        return searchDigits.contains(qDigits) ||
            (qDigits.startsWith("0") && qDigits.length > 2 && searchDigits.contains(qDigits.drop(1)))
    }
}
