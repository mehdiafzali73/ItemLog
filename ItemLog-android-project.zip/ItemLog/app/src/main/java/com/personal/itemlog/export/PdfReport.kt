package com.personal.itemlog.export

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.personal.itemlog.R
import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.RecordGroup
import com.personal.itemlog.domain.ReportText
import com.personal.itemlog.domain.TextNorm
import java.io.OutputStream

/** ساخت PDF فارسی و راست‌به‌چپ با Canvas؛ ستون‌های خالی در جدول نمایش داده نمی‌شوند. */
class PdfReport(context: Context) {
    private val regular: Typeface = ResourcesCompat.getFont(context, R.font.vazirmatn_regular) ?: Typeface.DEFAULT
    private val bold: Typeface = ResourcesCompat.getFont(context, R.font.vazirmatn_bold) ?: Typeface.DEFAULT_BOLD

    private val pageW = 595
    private val pageH = 842
    private val margin = 36f
    private val contentW = pageW - 2 * margin
    private val pad = 4f

    private fun paint(size: Float, isBold: Boolean = false, color: Int = Color.BLACK) =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            typeface = if (isBold) bold else regular
            this.color = color
        }

    private val titlePaint = paint(17f, true, 0xFF004D40.toInt())
    private val subPaint = paint(9.5f, false, 0xFF546E7A.toInt())
    private val groupPaint = paint(11f, true, 0xFF00332C.toInt())
    private val headerPaint = paint(9.5f, true)
    private val bodyPaint = paint(10f)
    private val notePaint = paint(9.5f, false, 0xFF37474F.toInt())
    private val footerPaint = paint(9f, false, 0xFF78909C.toInt())

    private val linePaint = Paint().apply { color = 0xFFB0BEC5.toInt(); strokeWidth = 0.6f }
    private val groupFill = Paint().apply { color = 0xFFB2DFDB.toInt(); style = Paint.Style.FILL }
    private val headerFill = Paint().apply { color = 0xFFE0F2F1.toInt(); style = Paint.Style.FILL }

    private class Col(val header: String, val fixedWidth: Float?, val text: (ItemRecord, Int) -> String)

    fun write(out: OutputStream, title: String, subtitle: String, groups: List<RecordGroup>) {
        val doc = PdfDocument()
        try {
            val session = Session(doc)
            session.newPage()
            session.drawParagraph(title, titlePaint, contentW)
            if (subtitle.isNotBlank()) session.drawParagraph(subtitle, subPaint, contentW)
            session.y += 4f
            session.drawRule()
            session.y += 8f

            if (groups.isEmpty()) {
                session.drawParagraph("موردی برای نمایش وجود ندارد.", bodyPaint, contentW)
            } else {
                val cols = columnsFor(groups.flatMap { it.records })
                for (g in groups) session.drawGroup(g, cols)
            }
            session.finishPage()
            doc.writeTo(out)
        } finally {
            doc.close()
        }
    }

    private fun columnsFor(records: List<ItemRecord>): List<Col> {
        val cols = mutableListOf<Col>()
        cols += Col("ردیف", 28f) { _, i -> TextNorm.toPersianDigits(i.toString()) }
        cols += Col("نام کالا", null) { r, _ -> r.productName.trim().ifEmpty { "—" } }
        if (records.any { it.productCode.isNotBlank() }) cols += Col("کد کالا", 52f) { r, _ -> r.productCode.trim() }
        if (records.any { it.quantity.isNotBlank() }) cols += Col("تعداد", 46f) { r, _ -> r.quantity.trim() }
        if (records.any { it.unit.isNotBlank() }) cols += Col("واحد", 42f) { r, _ -> r.unit.trim() }
        if (records.any { it.planningSite.isNotBlank() }) cols += Col("سایت برنامه‌ریزی", 88f) { r, _ -> r.planningSite.trim() }
        cols += Col("ساعت", 34f) { r, _ -> Jalali.formatTime(r.createdAt) }
        cols += Col("وضعیت", 38f) { r, _ -> ReportText.statusLabel(r) }
        return cols
    }

    private fun layout(text: String, p: TextPaint, width: Float, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width.toInt().coerceAtLeast(1))
            .setAlignment(align)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false)
            .build()

    private inner class Session(val doc: PdfDocument) {
        var pageNumber = 0
        lateinit var page: PdfDocument.Page
        lateinit var canvas: Canvas
        var y = 0f
        private var currentCols: List<Col>? = null
        private var currentWidths: List<Float> = emptyList()

        fun newPage() {
            if (pageNumber > 0) finishPage()
            pageNumber++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNumber).create())
            canvas = page.canvas
            y = margin
        }

        fun finishPage() {
            val footer = layout(
                "صفحه " + TextNorm.toPersianDigits(pageNumber.toString()),
                footerPaint, contentW, Layout.Alignment.ALIGN_CENTER
            )
            drawLayout(footer, margin, pageH - margin + 4f)
            doc.finishPage(page)
        }

        fun ensure(height: Float) {
            if (y + height > pageH - margin) {
                newPage()
                val cols = currentCols
                if (cols != null) drawTableHeader(cols)
            }
        }

        private fun drawLayout(l: StaticLayout, x: Float, top: Float) {
            canvas.save()
            canvas.translate(x, top)
            l.draw(canvas)
            canvas.restore()
        }

        fun drawRule() {
            canvas.drawLine(margin, y, margin + contentW, y, linePaint)
        }

        fun drawParagraph(text: String, p: TextPaint, width: Float) {
            val l = layout(text, p, width)
            ensure(l.height.toFloat() + 4f)
            drawLayout(l, margin, y)
            y += l.height + 4f
        }

        private fun widthsFor(cols: List<Col>): List<Float> {
            val fixed = cols.sumOf { (it.fixedWidth ?: 0f).toDouble() }.toFloat()
            val flex = contentW - fixed
            return cols.map { it.fixedWidth ?: flex }
        }

        fun drawGroup(g: RecordGroup, cols: List<Col>) {
            val who = listOf(g.contactName.trim(), g.contactPhone.trim())
                .filter { it.isNotEmpty() }.joinToString(" — ").ifEmpty { "بدون مخاطب" }
            val heading = layout("$who   •   ${Jalali.formatDate(g.date)}", groupPaint, contentW - 2 * pad)
            val headingH = heading.height + 2 * pad
            currentCols = null
            ensure(headingH + 70f)
            canvas.drawRect(margin, y, margin + contentW, y + headingH, groupFill)
            drawLayout(heading, margin + pad, y + pad)
            y += headingH

            currentCols = cols
            currentWidths = widthsFor(cols)
            drawTableHeader(cols)
            g.records.forEachIndexed { i, r -> drawRecord(cols, r, i + 1) }
            currentCols = null
            y += 12f
        }

        fun drawTableHeader(cols: List<Col>) {
            val widths = currentWidths
            val layouts = cols.mapIndexed { i, c -> layout(c.header, headerPaint, widths[i] - 2 * pad) }
            val h = (layouts.maxOfOrNull { it.height } ?: 0) + 2 * pad
            canvas.drawRect(margin, y, margin + contentW, y + h, headerFill)
            var right = margin + contentW
            layouts.forEachIndexed { i, l ->
                val left = right - widths[i]
                drawLayout(l, left + pad, y + pad)
                right = left
            }
            y += h
        }

        fun drawRecord(cols: List<Col>, r: ItemRecord, index: Int) {
            val widths = currentWidths
            val layouts = cols.mapIndexed { i, c ->
                val text = c.text(r, index)
                layout(text.ifEmpty { " " }, bodyPaint, widths[i] - 2 * pad)
            }
            val notesLayout = r.notes.trim().takeIf { it.isNotEmpty() }
                ?.let { layout("توضیحات: $it", notePaint, contentW - 2 * pad) }
            val rowH = (layouts.maxOfOrNull { it.height } ?: 0) + 2 * pad
            val total = rowH + (notesLayout?.height ?: 0) + (if (notesLayout != null) pad else 0f)
            ensure(total)

            var right = margin + contentW
            layouts.forEachIndexed { i, l ->
                val left = right - widths[i]
                drawLayout(l, left + pad, y + pad)
                right = left
            }
            var bottom = y + rowH
            if (notesLayout != null) {
                drawLayout(notesLayout, margin + pad, bottom - pad + 1f)
                bottom += notesLayout.height
            }
            canvas.drawLine(margin, bottom, margin + contentW, bottom, linePaint)
            y = bottom
        }
    }
}
