package com.personal.itemlog.export

import com.personal.itemlog.data.ItemRecord
import com.personal.itemlog.domain.Jalali
import com.personal.itemlog.domain.ReportText
import com.personal.itemlog.domain.TextNorm
import java.time.ZoneId

object ExcelRows {
    val HEADERS = listOf(
        "تاریخ", "ساعت", "نام مخاطب", "شماره تلفن", "کد کالا", "نام کالا",
        "تعداد", "واحد", "سایت برنامه‌ریزی", "توضیحات", "وضعیت", "تاریخ اتمام"
    )

    private val NUMBER = Regex("^\\d+(\\.\\d+)?$")

    /** تعداد عددی به‌صورت عدد ذخیره می‌شود تا در Excel قابل جمع‌زدن باشد؛ در غیر این صورت متن. */
    fun quantityCell(q: String): Any? {
        val t = TextNorm.toLatinDigits(q.trim())
        if (t.isEmpty()) return null
        return if (NUMBER.matches(t)) t.toDouble() else q.trim()
    }

    fun rows(records: List<ItemRecord>, zone: ZoneId = ZoneId.systemDefault()): List<List<Any?>> =
        records.map { r ->
            listOf(
                Jalali.formatNumeric(r.createdAt, zone),
                Jalali.formatTime(r.createdAt, zone),
                r.contactName,
                r.contactPhone,
                r.productCode,
                r.productName,
                quantityCell(r.quantity),
                r.unit,
                r.planningSite,
                r.notes,
                ReportText.statusLabel(r),
                r.completedAt?.let { Jalali.formatNumeric(it, zone) + " " + Jalali.formatTime(it, zone) }
            )
        }
}
